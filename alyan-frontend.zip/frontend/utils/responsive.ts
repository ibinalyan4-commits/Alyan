// Responsive utilities for tablets, iPads, foldables, and phones.
// Uses useWindowDimensions() so layouts auto-update on rotation/resize.

import { useWindowDimensions } from "react-native";

// Common breakpoints (matching Apple HIG + Material Design)
const PHONE_MAX = 600;       // < 600 = phone
const TABLET_MIN = 600;      // >= 600 = tablet
const LARGE_TABLET = 900;    // >= 900 = large tablet/iPad Pro
const DESKTOP_MIN = 1200;    // >= 1200 = desktop browser

export type ScreenSize = "phone" | "tablet" | "large-tablet" | "desktop";

export function useResponsive() {
  const { width, height } = useWindowDimensions();
  const isLandscape = width > height;
  const screen: ScreenSize =
    width >= DESKTOP_MIN ? "desktop" :
    width >= LARGE_TABLET ? "large-tablet" :
    width >= TABLET_MIN ? "tablet" :
    "phone";

  const isPhone = screen === "phone";
  const isTablet = screen === "tablet" || screen === "large-tablet";
  const isLargeTablet = screen === "large-tablet" || screen === "desktop";
  const isDesktop = screen === "desktop";

  // Maximum useful width for the main content (avoid stretched layouts on iPad)
  const contentMaxWidth = isDesktop ? 720 : isLargeTablet ? 720 : isTablet ? 640 : width;

  // How many columns of cards/categories to show
  const columns =
    isDesktop ? 3 :
    isLargeTablet && isLandscape ? 3 :
    isTablet ? 2 :
    1;

  // Scale factor for typography (1.0 phone → 1.18 large tablet)
  const fontScale =
    isDesktop ? 1.20 :
    isLargeTablet ? 1.18 :
    isTablet ? 1.10 :
    1.0;

  // Padding scaling
  const pad =
    isLargeTablet ? 32 :
    isTablet ? 24 :
    16;

  return {
    width,
    height,
    isLandscape,
    isPhone,
    isTablet,
    isLargeTablet,
    isDesktop,
    screen,
    columns,
    fontScale,
    contentMaxWidth,
    pad,
  };
}

/** Quick scale helper: scaleFont(16) → 16 on phone, 18.88 on iPad large */
export function scaleFont(base: number, factor: number): number {
  return Math.round(base * factor);
}
