import AsyncStorage from "@react-native-async-storage/async-storage";

const NAME_KEY = "user_name";
const ID_KEY = "user_id";

export async function getUser(): Promise<{ name: string; userId: string } | null> {
  const name = await AsyncStorage.getItem(NAME_KEY);
  const userId = await AsyncStorage.getItem(ID_KEY);
  if (name && userId) return { name, userId };
  return null;
}

export async function saveUser(name: string): Promise<{ name: string; userId: string }> {
  // Use existing id if any, otherwise generate
  let userId = await AsyncStorage.getItem(ID_KEY);
  if (!userId) {
    userId = `u_${Date.now()}_${Math.floor(Math.random() * 100000)}`;
    await AsyncStorage.setItem(ID_KEY, userId);
  }
  await AsyncStorage.setItem(NAME_KEY, name);
  return { name, userId };
}

export async function clearUser() {
  await AsyncStorage.multiRemove([NAME_KEY, ID_KEY]);
}
