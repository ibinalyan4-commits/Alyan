// Audio playback helper for TTS
import { Audio, InterruptionModeIOS, InterruptionModeAndroid } from "expo-av";
import { Platform } from "react-native";
import { BACKEND_URL } from "../constants/theme";

let currentSound: Audio.Sound | null = null;
let audioInitialized = false;

async function initAudio() {
  if (audioInitialized) return;
  try {
    await Audio.setAudioModeAsync({
      allowsRecordingIOS: false,
      playsInSilentModeIOS: true,
      staysActiveInBackground: false,
      interruptionModeIOS: InterruptionModeIOS.MixWithOthers,
      interruptionModeAndroid: InterruptionModeAndroid.DuckOthers,
      shouldDuckAndroid: true,
      playThroughEarpieceAndroid: false,
    });
    audioInitialized = true;
  } catch (e) {
    console.warn("Audio init failed", e);
  }
}

export async function playTTS(text: string, voice: string = "onyx") {
  if (!text || !text.trim()) return;
  try {
    await initAudio();
    if (currentSound) {
      try { await currentSound.unloadAsync(); } catch {}
      currentSound = null;
    }
    const data = await fetchTTSCached(text, voice);
    if (!data) return;
    const uri = `data:audio/mp3;base64,${data}`;
    const { sound } = await Audio.Sound.createAsync(
      { uri },
      { shouldPlay: true, volume: 1.0 }
    );
    currentSound = sound;
    sound.setOnPlaybackStatusUpdate((status: any) => {
      if (status.didJustFinish) {
        sound.unloadAsync().catch(() => {});
        if (currentSound === sound) currentSound = null;
      }
    });
    // Web sometimes needs explicit play after createAsync
    if (Platform.OS === "web") {
      try { await sound.playAsync(); } catch {}
    }
  } catch (e) {
    console.error("playTTS error", e);
  }
}

// In-memory cache for TTS base64 audio so replays/preloads are INSTANT
const ttsCache: Map<string, string> = new Map();
const TTS_CACHE_MAX = 60;
const inFlight: Map<string, Promise<string | null>> = new Map();

function cacheKey(text: string, voice: string) {
  return `${voice}::${text.slice(0, 400).trim()}`;
}

async function fetchTTSCached(text: string, voice: string): Promise<string | null> {
  const key = cacheKey(text, voice);
  const cached = ttsCache.get(key);
  if (cached) return cached;
  const existing = inFlight.get(key);
  if (existing) return existing;
  const p = (async () => {
    try {
      const res = await fetch(`${BACKEND_URL}/api/tts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: text.slice(0, 400), voice }),
      });
      if (!res.ok) {
        console.error("TTS failed", res.status);
        return null;
      }
      const data = await res.json();
      const b64 = data?.audio_base64;
      if (!b64) return null;
      // Insert into cache (LRU-ish: drop oldest when over capacity)
      if (ttsCache.size >= TTS_CACHE_MAX) {
        const firstKey = ttsCache.keys().next().value;
        if (firstKey) ttsCache.delete(firstKey);
      }
      ttsCache.set(key, b64);
      return b64;
    } catch (e) {
      console.error("fetchTTSCached error", e);
      return null;
    } finally {
      inFlight.delete(key);
    }
  })();
  inFlight.set(key, p);
  return p;
}

// Pre-fetch TTS audio so the next playback is instant
export function prefetchTTS(text: string | undefined | null, voice: string = "onyx"): void {
  if (!text || !text.trim()) return;
  void fetchTTSCached(text, voice);
}
