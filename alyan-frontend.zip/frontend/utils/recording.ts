// Voice recording for speech-to-text.
// On native (iOS/Android) uses expo-av.
// On web uses the browser's MediaRecorder API directly for reliability.
import { Audio } from "expo-av";
import { Platform } from "react-native";
import { BACKEND_URL } from "../constants/theme";

let currentNativeRecording: Audio.Recording | null = null;

// Web-specific state
let webMediaRecorder: any = null;
let webStream: MediaStream | null = null;
let webChunks: Blob[] = [];
let webMimeType: string = "audio/webm";

export type MicPermissionResult = {
  granted: boolean;
  canAskAgain: boolean;
  status: string;
};

// =============== PERMISSIONS ===============
export async function requestMicPermission(): Promise<boolean> {
  const r = await requestMicPermissionDetailed();
  return r.granted;
}

export async function requestMicPermissionDetailed(): Promise<MicPermissionResult> {
  // Web path — use Permissions API + getUserMedia directly
  if (Platform.OS === "web") {
    try {
      // Some browsers (Safari) don't have navigator.permissions for microphone
      // so we just attempt getUserMedia
      const stream = await (navigator as any).mediaDevices.getUserMedia({ audio: true });
      // Stop the stream immediately, we just wanted to check
      stream.getTracks().forEach((t: MediaStreamTrack) => t.stop());
      return { granted: true, canAskAgain: true, status: "granted" };
    } catch (e: any) {
      console.warn("Web mic permission error:", e?.name, e?.message);
      const denied = e?.name === "NotAllowedError" || e?.name === "PermissionDeniedError";
      return { granted: false, canAskAgain: !denied, status: denied ? "denied" : "error" };
    }
  }

  // Native path — use expo-av
  try {
    const current = await Audio.getPermissionsAsync();
    if (current.status === "granted") {
      return { granted: true, canAskAgain: true, status: current.status };
    }
    const { status, canAskAgain } = await Audio.requestPermissionsAsync();
    return { granted: status === "granted", canAskAgain: canAskAgain ?? true, status };
  } catch (e) {
    console.warn("requestMicPermissionDetailed error", e);
    return { granted: false, canAskAgain: true, status: "error" };
  }
}

// =============== START RECORDING ===============
export async function startRecording(): Promise<boolean> {
  if (Platform.OS === "web") {
    return startWebRecording();
  }
  return startNativeRecording();
}

async function startWebRecording(): Promise<boolean> {
  try {
    // Request access to microphone with a stream we keep alive while recording
    const stream = await (navigator as any).mediaDevices.getUserMedia({ audio: true });
    webStream = stream;
    webChunks = [];

    // Pick the best supported mime type
    const candidates = [
      "audio/webm;codecs=opus",
      "audio/webm",
      "audio/mp4",
      "audio/ogg;codecs=opus",
    ];
    let chosen = "";
    const MR = (window as any).MediaRecorder;
    if (MR && typeof MR.isTypeSupported === "function") {
      for (const c of candidates) {
        if (MR.isTypeSupported(c)) { chosen = c; break; }
      }
    }
    webMimeType = chosen || "audio/webm";

    const recorder = chosen ? new MR(stream, { mimeType: chosen }) : new MR(stream);
    recorder.ondataavailable = (event: any) => {
      if (event.data && event.data.size > 0) webChunks.push(event.data);
    };
    recorder.onerror = (e: any) => {
      console.error("MediaRecorder error", e);
    };
    recorder.start();
    webMediaRecorder = recorder;
    return true;
  } catch (e) {
    console.error("startWebRecording error", e);
    cleanupWeb();
    return false;
  }
}

async function startNativeRecording(): Promise<boolean> {
  try {
    const ok = await requestMicPermission();
    if (!ok) return false;
    await Audio.setAudioModeAsync({
      allowsRecordingIOS: true,
      playsInSilentModeIOS: true,
    });
    if (currentNativeRecording) {
      try { await currentNativeRecording.stopAndUnloadAsync(); } catch {}
      currentNativeRecording = null;
    }
    const rec = new Audio.Recording();
    await rec.prepareToRecordAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
    await rec.startAsync();
    currentNativeRecording = rec;
    return true;
  } catch (e) {
    console.error("startNativeRecording error", e);
    return false;
  }
}

// =============== STOP & TRANSCRIBE ===============
export async function stopRecordingAndTranscribe(language: string = "en"): Promise<string | null> {
  if (Platform.OS === "web") {
    return stopWebAndTranscribe(language);
  }
  return stopNativeAndTranscribe(language);
}

async function stopWebAndTranscribe(language: string): Promise<string | null> {
  const recorder = webMediaRecorder;
  if (!recorder) return null;

  // Wait for the final dataavailable event
  const stopped: Promise<void> = new Promise((resolve) => {
    recorder.onstop = () => resolve();
    try { recorder.stop(); } catch { resolve(); }
  });
  await stopped;

  // Stop the mic stream
  cleanupWeb(false);

  if (!webChunks.length) {
    webChunks = [];
    return null;
  }

  const blob = new Blob(webChunks, { type: webMimeType });
  webChunks = [];

  if (blob.size < 1000) {
    // Too small to be valid audio
    return null;
  }

  // Convert blob to base64
  const base64 = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      const idx = result.indexOf(",");
      resolve(idx >= 0 ? result.substring(idx + 1) : result);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });

  return await sendToSTT(base64, blob.type || webMimeType, language);
}

async function stopNativeAndTranscribe(language: string): Promise<string | null> {
  if (!currentNativeRecording) return null;
  try {
    await currentNativeRecording.stopAndUnloadAsync();
    const uri = currentNativeRecording.getURI();
    currentNativeRecording = null;
    try {
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
        playsInSilentModeIOS: true,
      });
    } catch {}
    if (!uri) return null;

    const FileSystem = require("expo-file-system");
    const base64 = await FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    return await sendToSTT(base64, "audio/m4a", language);
  } catch (e) {
    console.error("stopNativeAndTranscribe error", e);
    return null;
  }
}

async function sendToSTT(base64: string, mime: string, language: string): Promise<string | null> {
  try {
    const res = await fetch(`${BACKEND_URL}/api/stt`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ audio_base64: base64, mime, language }),
    });
    if (!res.ok) {
      console.error("STT failed", res.status, await res.text());
      return null;
    }
    const data = await res.json();
    return (data?.text || "").toString().trim() || null;
  } catch (e) {
    console.error("sendToSTT error", e);
    return null;
  }
}

// =============== CANCEL ===============
export async function cancelRecording() {
  if (Platform.OS === "web") {
    if (webMediaRecorder) {
      try { webMediaRecorder.stop(); } catch {}
    }
    cleanupWeb();
    webChunks = [];
    return;
  }
  if (!currentNativeRecording) return;
  try { await currentNativeRecording.stopAndUnloadAsync(); } catch {}
  currentNativeRecording = null;
  try {
    await Audio.setAudioModeAsync({
      allowsRecordingIOS: false,
      playsInSilentModeIOS: true,
    });
  } catch {}
}

function cleanupWeb(clearRecorder: boolean = true) {
  if (webStream) {
    try { webStream.getTracks().forEach((t) => t.stop()); } catch {}
    webStream = null;
  }
  if (clearRecorder) {
    webMediaRecorder = null;
  }
}
