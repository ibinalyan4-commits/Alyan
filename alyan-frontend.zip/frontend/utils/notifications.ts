import * as Notifications from "expo-notifications";
import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const SETTINGS_KEY = "reminder_settings";
const NOTIF_ID_KEY = "reminder_notif_id";

export type ReminderSettings = {
  enabled: boolean;
  hour: number;   // 0-23
  minute: number; // 0-59
};

export const DEFAULT_SETTINGS: ReminderSettings = {
  enabled: false,
  hour: 19,
  minute: 0,
};

export async function getSettings(): Promise<ReminderSettings> {
  const raw = await AsyncStorage.getItem(SETTINGS_KEY);
  if (!raw) return DEFAULT_SETTINGS;
  try { return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) }; } catch { return DEFAULT_SETTINGS; }
}

export async function saveSettings(s: ReminderSettings) {
  await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}

export async function requestPermission(): Promise<boolean> {
  if (Platform.OS === "web") return false; // notifications not supported in web preview
  const { status } = await Notifications.getPermissionsAsync();
  if (status === "granted") return true;
  const { status: req } = await Notifications.requestPermissionsAsync();
  return req === "granted";
}

export async function scheduleDailyReminder(hour: number, minute: number, name?: string) {
  if (Platform.OS === "web") return null;
  // Cancel previous
  await cancelReminder();

  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: false,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });

  const id = await Notifications.scheduleNotificationAsync({
    content: {
      title: name ? `وقت التعلم يا ${name}! 🇸🇦` : "وقت التعلم! 🇸🇦",
      body: "عليان بانتظارك لدرس جديد. لا تكسر سلسلتك!",
      sound: "default",
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DAILY,
      hour,
      minute,
    } as any,
  });
  await AsyncStorage.setItem(NOTIF_ID_KEY, id);
  return id;
}

export async function cancelReminder() {
  if (Platform.OS === "web") return;
  const id = await AsyncStorage.getItem(NOTIF_ID_KEY);
  if (id) {
    try { await Notifications.cancelScheduledNotificationAsync(id); } catch {}
  }
  await AsyncStorage.removeItem(NOTIF_ID_KEY);
}
