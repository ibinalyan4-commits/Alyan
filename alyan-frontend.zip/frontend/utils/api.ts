// Resilient fetch wrapper with timeout + exponential backoff retry for transient errors.
// Use for any non-idempotent or critical API call from the app.

import { BACKEND_URL } from "../constants/theme";

type FetchOpts = RequestInit & {
  timeoutMs?: number;
  retries?: number;
  retryOn?: number[];   // HTTP status codes that trigger a retry
};

/**
 * Race a fetch against a timeout. Aborts the request if it exceeds timeoutMs.
 */
function fetchWithTimeout(url: string, opts: RequestInit, timeoutMs: number): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  return fetch(url, { ...opts, signal: controller.signal })
    .finally(() => clearTimeout(timer));
}

/**
 * Resilient fetch with:
 *  - timeoutMs (default 25s)
 *  - retries (default 2) for HTTP 5xx, 504 timeouts, network errors
 *  - exponential backoff: 400ms, 1.2s, 3.6s
 */
export async function safeFetch<T = any>(
  path: string,
  opts: FetchOpts = {}
): Promise<{ ok: boolean; status: number; data?: T; error?: string }> {
  const {
    timeoutMs = 25000,
    retries = 2,
    retryOn = [502, 503, 504],
    ...init
  } = opts;
  const url = path.startsWith("http") ? path : `${BACKEND_URL}${path}`;

  let attempt = 0;
  let lastError = "unknown";
  let lastStatus = 0;

  while (attempt <= retries) {
    try {
      const res = await fetchWithTimeout(url, init, timeoutMs);
      lastStatus = res.status;
      if (res.ok) {
        const data = (await res.json().catch(() => undefined)) as T;
        return { ok: true, status: res.status, data };
      }
      // 4xx (except 429 which we treat separately) — don't retry, bail
      if (res.status < 500 && res.status !== 429 && !retryOn.includes(res.status)) {
        const text = await res.text().catch(() => "");
        return { ok: false, status: res.status, error: text };
      }
      // Retry-eligible
      lastError = `HTTP ${res.status}`;
    } catch (e: any) {
      // Network or timeout error
      lastError = e?.name === "AbortError" ? "timeout" : (e?.message || "network");
    }
    attempt += 1;
    if (attempt > retries) break;
    // Exponential backoff: 400ms, 1.2s, 3.6s
    const wait = 400 * Math.pow(3, attempt - 1);
    await new Promise((r) => setTimeout(r, wait));
  }
  return { ok: false, status: lastStatus, error: lastError };
}

/** Convenience wrapper for POST JSON with retry */
export function safePostJSON<T = any>(path: string, body: any, opts: FetchOpts = {}) {
  return safeFetch<T>(path, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(opts.headers || {}) },
    body: JSON.stringify(body),
    ...opts,
  });
}

/** Convenience wrapper for GET JSON with retry */
export function safeGetJSON<T = any>(path: string, opts: FetchOpts = {}) {
  return safeFetch<T>(path, { method: "GET", ...opts });
}
