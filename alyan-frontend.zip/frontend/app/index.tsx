import { useEffect, useRef, useState } from "react";
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, ActivityIndicator,
  Modal, Animated, Easing,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { COLORS, NEO_SHADOW } from "../constants/theme";
import { getUser, saveUser } from "../utils/user";

const AD_NOTICE_DURATION_MS = 5000;

export default function Onboarding() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [checking, setChecking] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [showAdNotice, setShowAdNotice] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(Math.ceil(AD_NOTICE_DURATION_MS / 1000));
  const progressAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    (async () => {
      const u = await getUser();
      if (u) {
        // Returning user: skip onboarding & ad notice, go directly to app
        router.replace("/(tabs)");
      } else {
        // New user: show onboarding (name entry)
        setChecking(false);
      }
    })();
  }, [router]);

  const goToApp = () => {
    setShowAdNotice(false);
    router.replace("/(tabs)");
  };

  useEffect(() => {
    if (!showAdNotice) return;

    progressAnim.setValue(0);
    Animated.timing(progressAnim, {
      toValue: 1,
      duration: AD_NOTICE_DURATION_MS,
      easing: Easing.linear,
      useNativeDriver: false,
    }).start();

    setSecondsLeft(Math.ceil(AD_NOTICE_DURATION_MS / 1000));
    const interval = setInterval(() => {
      setSecondsLeft((s) => (s > 1 ? s - 1 : 1));
    }, 1000);
    const timer = setTimeout(() => {
      goToApp();
    }, AD_NOTICE_DURATION_MS);

    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showAdNotice]);

  const submit = async () => {
    const trimmed = name.trim();
    if (!trimmed) return;
    setSubmitting(true);
    await saveUser(trimmed);
    setSubmitting(false);
    setShowAdNotice(true);
  };

  if (checking) {
    return (
      <SafeAreaView style={styles.safe}>
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 200 }} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.emoji}>🇸🇦</Text>
            <Text style={styles.title}>أهلاً بك!</Text>
            <Text style={styles.subtitle}>
              تطبيق تعلّم الإنجليزية{"\n"}بسهولة وإبداع
            </Text>
          </View>

          <View style={[styles.card, NEO_SHADOW]}>
            <Text style={styles.label}>ما اسمك؟</Text>
            <TextInput
              testID="onboarding-name-input"
              style={styles.input}
              value={name}
              onChangeText={setName}
              placeholder="اكتب اسمك هنا..."
              placeholderTextColor={COLORS.placeholder}
              autoFocus
              maxLength={30}
              onSubmitEditing={submit}
              returnKeyType="go"
            />
            <TouchableOpacity
              testID="onboarding-submit"
              style={[styles.button, NEO_SHADOW, (!name.trim() || submitting) && { opacity: 0.5 }]}
              onPress={submit}
              disabled={!name.trim() || submitting}
              activeOpacity={0.85}
            >
              {submitting ? (
                <ActivityIndicator color={COLORS.textInverse} />
              ) : (
                <>
                  <Text style={styles.buttonText}>ابدأ التعلم</Text>
                  <Ionicons name="arrow-back" size={20} color={COLORS.textInverse} />
                </>
              )}
            </TouchableOpacity>
            <Text style={styles.hint}>لا حاجة لكلمة مرور — استخدم التطبيق مباشرة</Text>
          </View>

          <View style={styles.featureRow}>
            <Feat icon="book" label="دروس" />
            <Feat icon="albums" label="بطاقات" />
            <Feat icon="chatbubbles" label="محادثة AI" />
            <Feat icon="mic" label="نطق" />
          </View>
        </View>
      </KeyboardAvoidingView>

      <Modal
        visible={showAdNotice}
        transparent
        animationType="fade"
        onRequestClose={goToApp}
      >
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, NEO_SHADOW]}>
            <View style={styles.modalIconWrap}>
              <Ionicons name="megaphone" size={32} color={COLORS.primary} />
            </View>
            <Text style={styles.modalTitle}>الإعلانات</Text>
            <Text style={styles.modalBody}>
              تظهر الإعلانات صغيرة في الأعلى فقط، بحيث{"\n"}
              لا تؤثر على تجربة التعلم لكي نستمر بتقديم{"\n"}
              التطبيق مجاناً لكم.
            </Text>
            <Text style={styles.modalThanks}>شكراً لتفهمكم 🌹</Text>

            <View style={styles.progressTrack}>
              <Animated.View
                style={[
                  styles.progressBar,
                  {
                    width: progressAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: ["0%", "100%"],
                    }),
                  },
                ]}
              />
            </View>

            <TouchableOpacity
              testID="ad-notice-continue"
              style={styles.modalButton}
              onPress={goToApp}
              activeOpacity={0.85}
            >
              <Text style={styles.modalButtonText}>
                متابعة ({secondsLeft})
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function Feat({ icon, label }: { icon: any; label: string }) {
  return (
    <View style={styles.feat}>
      <View style={styles.featIcon}>
        <Ionicons name={icon} size={18} color={COLORS.primary} />
      </View>
      <Text style={styles.featLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  container: { flex: 1, padding: 24, justifyContent: "space-between" },
  header: { alignItems: "center", marginTop: 40 },
  emoji: { fontSize: 80, marginBottom: 8 },
  title: { fontSize: 36, fontWeight: "900", color: COLORS.textPrimary, textAlign: "center" },
  subtitle: { fontSize: 16, color: COLORS.textSecondary, marginTop: 12, textAlign: "center", fontWeight: "600", lineHeight: 24 },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: 22,
    borderWidth: 2,
    borderColor: COLORS.border,
    padding: 22,
  },
  label: { fontSize: 14, fontWeight: "800", color: COLORS.textSecondary, textAlign: "right", marginBottom: 10 },
  input: {
    backgroundColor: COLORS.bg,
    borderWidth: 2,
    borderColor: COLORS.border,
    borderRadius: 14,
    padding: 14,
    fontSize: 18,
    color: COLORS.textPrimary,
    textAlign: "right",
    fontWeight: "700",
  },
  button: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    backgroundColor: COLORS.primary,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: COLORS.border,
    padding: 16,
    marginTop: 14,
  },
  buttonText: { color: COLORS.textInverse, fontWeight: "900", fontSize: 17 },
  hint: { fontSize: 11, color: COLORS.textSecondary, marginTop: 12, textAlign: "center", fontWeight: "600" },
  featureRow: { flexDirection: "row-reverse", justifyContent: "space-around", marginBottom: 20 },
  feat: { alignItems: "center", gap: 6 },
  featIcon: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },
  featLabel: { fontSize: 11, color: COLORS.textSecondary, fontWeight: "700" },

  // Ad Notice Modal
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.55)",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 24,
  },
  modalCard: {
    width: "100%",
    maxWidth: 380,
    backgroundColor: COLORS.surface,
    borderRadius: 22,
    borderWidth: 2,
    borderColor: COLORS.border,
    padding: 22,
    alignItems: "center",
  },
  modalIconWrap: {
    width: 64,
    height: 64,
    borderRadius: 18,
    backgroundColor: COLORS.surface2,
    borderWidth: 2,
    borderColor: COLORS.border,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: "900",
    color: COLORS.textPrimary,
    textAlign: "center",
    marginBottom: 10,
  },
  modalBody: {
    fontSize: 15,
    color: COLORS.textSecondary,
    textAlign: "center",
    fontWeight: "600",
    lineHeight: 24,
  },
  modalThanks: {
    fontSize: 14,
    color: COLORS.primary,
    textAlign: "center",
    fontWeight: "800",
    marginTop: 12,
  },
  progressTrack: {
    width: "100%",
    height: 4,
    backgroundColor: COLORS.border,
    borderRadius: 4,
    marginTop: 16,
    overflow: "hidden",
  },
  progressBar: {
    height: 4,
    backgroundColor: COLORS.primary,
    borderRadius: 4,
  },
  modalButton: {
    marginTop: 14,
    paddingVertical: 12,
    paddingHorizontal: 28,
    backgroundColor: COLORS.primary,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: COLORS.border,
  },
  modalButtonText: {
    color: COLORS.textInverse,
    fontWeight: "900",
    fontSize: 15,
  },
});
