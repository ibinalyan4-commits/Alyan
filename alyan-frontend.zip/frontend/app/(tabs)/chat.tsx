import { useEffect, useRef, useState, useCallback } from "react";
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator,
  Modal, Pressable, Alert, Linking,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "expo-router";
import { COLORS, NEO_SHADOW, NEO_SHADOW_SM, BACKEND_URL } from "../../constants/theme";
import { playTTS, prefetchTTS } from "../../utils/audio";
import { useResponsive } from "../../utils/responsive";
import { getUser } from "../../utils/user";
import { startRecording, stopRecordingAndTranscribe, cancelRecording, requestMicPermissionDetailed } from "../../utils/recording";

type Correction = {
  has_error: boolean;
  original?: string;
  corrected?: string;
  explanation_ar?: string;
};

type Msg = {
  role: "user" | "assistant";
  text: string;          // English (assistant) or original (user)
  reply_ar?: string;
  suggestions?: string[];
  correction?: Correction | null;
};

type Scenario = { id: string; name_ar: string; emoji: string; opener: string };

const SCENARIOS_FALLBACK: Scenario[] = [
  { id: "free", name_ar: "محادثة حرة", emoji: "💬", opener: "" },
];

const LEVELS: { id: "beginner" | "intermediate" | "advanced"; label: string }[] = [
  { id: "beginner", label: "مبتدئ" },
  { id: "intermediate", label: "متوسط" },
  { id: "advanced", label: "متقدم" },
];

export default function Chat() {
  const [scenarios, setScenarios] = useState<Scenario[]>(SCENARIOS_FALLBACK);
  const [scenario, setScenario] = useState<string>("free");
  const [level, setLevel] = useState<"beginner" | "intermediate" | "advanced">("beginner");
  const [autoPlay, setAutoPlay] = useState<boolean>(true);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [userId, setUserId] = useState<string>("default");
  const [pickerOpen, setPickerOpen] = useState(false);
  const [translateModal, setTranslateModal] = useState<{ word: string; result: string; loading: boolean } | null>(null);
  const [showTranslations, setShowTranslations] = useState<Record<number, boolean>>({});
  const [suggestModal, setSuggestModal] = useState<{ reply_en: string; reply_ar: string; loading: boolean } | null>(null);
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const scrollRef = useRef<ScrollView>(null);
  const responsive = useResponsive();

  const sessionId = `${userId}_chat_${scenario}_${level}`;

  // Load scenarios + user
  useEffect(() => {
    fetch(`${BACKEND_URL}/api/chat/scenarios`)
      .then(r => r.json())
      .then((s) => Array.isArray(s) && s.length ? setScenarios(s) : null)
      .catch(() => {});
    getUser().then(u => { if (u) setUserId(u.userId); });
  }, []);

  // Set opener message when scenario or scenarios change
  useEffect(() => {
    const sc = scenarios.find(s => s.id === scenario);
    if (sc && sc.opener) {
      setMessages([{ role: "assistant", text: sc.opener, reply_ar: "" }]);
    }
  }, [scenario, scenarios]);

  useEffect(() => {
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
  }, [messages]);

  const send = async (overrideText?: string) => {
    const text = (overrideText ?? input).trim();
    if (!text || sending) return;
    setMessages((m) => [...m, { role: "user", text }]);
    setInput("");
    setSending(true);
    try {
      const res = await fetch(`${BACKEND_URL}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, message: text, scenario, level }),
      });
      if (!res.ok) {
        setMessages((m) => [...m, { role: "assistant", text: "الخادم مشغول حالياً، حاول مرة أخرى بعد لحظات." }]);
        return;
      }
      let data: any = null;
      try { data = await res.json(); } catch {
        setMessages((m) => [...m, { role: "assistant", text: "تعذرت قراءة الرد، حاول مرة أخرى." }]);
        return;
      }
      if (data?.reply_en) {
        const assistantMsg: Msg = {
          role: "assistant",
          text: data.reply_en,
          reply_ar: data.reply_ar,
          suggestions: data.suggestions || [],
          correction: data.correction || null,
        };
        setMessages((m) => [...m, assistantMsg]);
        if (autoPlay && data.reply_en) {
          setTimeout(() => playTTS(data.reply_en), 300);
        }
      } else {
        setMessages((m) => [...m, { role: "assistant", text: "عذراً، حدث خطأ. حاول مرة أخرى." }]);
      }
    } catch (e) {
      console.error(e);
      setMessages((m) => [...m, { role: "assistant", text: "عذراً، فشل الاتصال." }]);
    } finally {
      setSending(false);
    }
  };

  const resetChat = async () => {
    try {
      await fetch(`${BACKEND_URL}/api/chat/${sessionId}/reset`, { method: "POST" });
    } catch {}
    const sc = scenarios.find(s => s.id === scenario);
    setMessages(sc && sc.opener ? [{ role: "assistant", text: sc.opener }] : []);
  };

  const toggleRecording = async () => {
    if (transcribing || sending) return;
    if (!recording) {
      // Pre-flight: check & request mic permission so user sees the OS prompt
      const perm = await requestMicPermissionDetailed();
      if (!perm.granted) {
        // Permission denied or blocked — guide user
        if (Platform.OS === "web") {
          Alert.alert(
            "إذن الميكروفون مطلوب",
            "يحتاج المتصفح لإذن استخدام الميكروفون لتسجيل صوتك. اضغط على أيقونة القفل بجوار شريط العنوان واسمح بالميكروفون ثم أعد المحاولة.",
            [{ text: "حسناً" }]
          );
        } else if (!perm.canAskAgain) {
          Alert.alert(
            "إذن الميكروفون مرفوض",
            "لقد رفضت إذن الميكروفون سابقاً. الرجاء فتح إعدادات التطبيق وتفعيل الميكروفون يدوياً.",
            [
              { text: "إلغاء", style: "cancel" },
              { text: "فتح الإعدادات", onPress: () => Linking.openSettings() },
            ]
          );
        } else {
          Alert.alert(
            "إذن الميكروفون مطلوب",
            "للتحدث مع المعلم عليان نحتاج إذن استخدام الميكروفون. حاول الضغط على زر التسجيل مرة أخرى ووافق على الإذن.",
            [{ text: "حسناً" }]
          );
        }
        return;
      }
      const ok = await startRecording();
      if (!ok) {
        Alert.alert("تعذّر التسجيل", "فشل بدء التسجيل، حاول مرة أخرى.");
        return;
      }
      setRecording(true);
    } else {
      setRecording(false);
      setTranscribing(true);
      const text = await stopRecordingAndTranscribe("en");
      setTranscribing(false);
      if (text && text.trim()) {
        await send(text);
      } else {
        setMessages((m) => [...m, { role: "assistant", text: "لم أسمع شيئاً، حاول مجدداً 🎙️" }]);
      }
    }
  };

  const ensureTranslation = async (msgIndex: number) => {
    const m = messages[msgIndex];
    if (!m || m.role !== "assistant") return;
    if (m.reply_ar) {
      setShowTranslations(t => ({ ...t, [msgIndex]: !t[msgIndex] }));
      return;
    }
    // Fetch translation from server
    setShowTranslations(t => ({ ...t, [msgIndex]: true }));
    setMessages((curr) => curr.map((mm, idx) => idx === msgIndex ? { ...mm, reply_ar: "..." } : mm));
    try {
      const res = await fetch(`${BACKEND_URL}/api/translate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ word: m.text }),
      });
      const data = await res.json();
      const translation = data.translation || "تعذرت الترجمة";
      setMessages((curr) => curr.map((mm, idx) => idx === msgIndex ? { ...mm, reply_ar: translation } : mm));
    } catch {
      setMessages((curr) => curr.map((mm, idx) => idx === msgIndex ? { ...mm, reply_ar: "تعذرت الترجمة" } : mm));
    }
  };

  const translateWord = async (word: string) => {
    const cleaned = word.replace(/[^a-zA-Z'-]/g, "");
    if (!cleaned) return;
    setTranslateModal({ word: cleaned, result: "", loading: true });
    try {
      const res = await fetch(`${BACKEND_URL}/api/translate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ word: cleaned }),
      });
      const data = await res.json();
      setTranslateModal({ word: cleaned, result: data.translation || "—", loading: false });
    } catch {
      setTranslateModal({ word: cleaned, result: "تعذرت الترجمة", loading: false });
    }
  };

  const suggestReply = async (lastAiMessage: string) => {
    setSuggestModal({ reply_en: "", reply_ar: "", loading: true });
    try {
      const res = await fetch(`${BACKEND_URL}/api/chat/suggest-reply`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ last_ai_message: lastAiMessage, level }),
      });
      if (!res.ok) throw new Error("failed");
      const data = await res.json();
      setSuggestModal({
        reply_en: data.reply_en || "",
        reply_ar: data.reply_ar || "",
        loading: false,
      });
    } catch {
      setSuggestModal({ reply_en: "", reply_ar: "تعذر اقتراح إجابة، حاول مجدداً", loading: false });
    }
  };

  const useSuggestedReply = (sendImmediately: boolean) => {
    if (!suggestModal?.reply_en) return;
    if (sendImmediately) {
      const txt = suggestModal.reply_en;
      setSuggestModal(null);
      send(txt);
    } else {
      setInput(suggestModal.reply_en);
      setSuggestModal(null);
    }
  };

  const currentScenario = scenarios.find(s => s.id === scenario) || SCENARIOS_FALLBACK[0];
  const lastMsg = messages[messages.length - 1];
  const showSuggestions = lastMsg?.role === "assistant" && lastMsg.suggestions && lastMsg.suggestions.length > 0 && !sending;

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        {/* Header with Alyan + scenario picker + reset */}
        <View style={styles.header}>
          <View style={[styles.avatar, NEO_SHADOW_SM]}>
            <Text style={{ fontSize: 26 }}>🇸🇦</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.headerTitle}>عليان - مدرس الإنجليزية</Text>
            <TouchableOpacity onPress={() => setPickerOpen(true)} testID="open-scenario-picker">
              <Text style={styles.headerSub}>
                {currentScenario.emoji} {currentScenario.name_ar} · {LEVELS.find(l => l.id === level)?.label}  ▾
              </Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            testID="chat-autoplay-toggle"
            style={[styles.iconBtn, NEO_SHADOW_SM, autoPlay && { backgroundColor: COLORS.success }]}
            onPress={() => setAutoPlay(!autoPlay)}
          >
            <Ionicons name={autoPlay ? "volume-high" : "volume-mute"} size={18} color={COLORS.textPrimary} />
          </TouchableOpacity>
          <TouchableOpacity
            testID="chat-reset"
            style={[styles.iconBtn, NEO_SHADOW_SM]}
            onPress={resetChat}
          >
            <Ionicons name="refresh" size={18} color={COLORS.textPrimary} />
          </TouchableOpacity>
        </View>

        <ScrollView
          ref={scrollRef}
          style={{ flex: 1 }}
          contentContainerStyle={[styles.messages, { maxWidth: responsive.contentMaxWidth, alignSelf: "center", width: "100%" }]}
          showsVerticalScrollIndicator={false}
        >
          {messages.map((m, i) => (
            <View key={i} testID={`chat-msg-${i}`}>
              {/* Correction banner ABOVE the assistant message that contains the correction */}
              {m.role === "assistant" && m.correction?.has_error && (
                <View style={[styles.correctionCard, NEO_SHADOW_SM]} testID={`chat-correction-${i}`}>
                  <View style={styles.correctionHeader}>
                    <Ionicons name="warning" size={14} color={COLORS.warning} />
                    <Text style={styles.correctionTitle}>تصحيح</Text>
                  </View>
                  <Text style={styles.correctionRow}>
                    <Text style={styles.correctionLabel}>الخطأ: </Text>
                    <Text style={styles.correctionWrong}>{m.correction.original}</Text>
                  </Text>
                  <Text style={styles.correctionRow}>
                    <Text style={styles.correctionLabel}>الصحيح: </Text>
                    <Text style={styles.correctionRight}>{m.correction.corrected}</Text>
                  </Text>
                  {!!m.correction.explanation_ar && (
                    <Text style={styles.correctionExplain}>{m.correction.explanation_ar}</Text>
                  )}
                </View>
              )}

              <View
                style={[
                  styles.bubble,
                  m.role === "user" ? styles.bubbleUser : [styles.bubbleBot, NEO_SHADOW_SM],
                ]}
              >
                {/* Tappable English words */}
                <View style={styles.wordsRow}>
                  {(m.text || "").split(/(\s+)/).map((tok, idx) =>
                    /\s+/.test(tok) ? (
                      <Text key={idx} style={[styles.wordText, m.role === "user" && styles.wordTextUser]}>
                        {tok}
                      </Text>
                    ) : (
                      <TouchableOpacity
                        key={idx}
                        onPress={() => m.role === "assistant" && translateWord(tok)}
                        activeOpacity={m.role === "assistant" ? 0.6 : 1}
                      >
                        <Text style={[styles.wordText, m.role === "user" && styles.wordTextUser]}>
                          {tok}
                        </Text>
                      </TouchableOpacity>
                    )
                  )}
                </View>

                {!!m.reply_ar && showTranslations[i] && (
                  <Text style={styles.bubbleArabic}>{m.reply_ar}</Text>
                )}

                {m.role === "assistant" && (
                  <View style={styles.bubbleActions}>
                    <TouchableOpacity
                      style={styles.ttsBtn}
                      onPress={() => playTTS(m.text)}
                      testID={`chat-tts-${i}`}
                    >
                      <Ionicons name="volume-high" size={14} color={COLORS.textPrimary} />
                      <Text style={styles.ttsBtnText}>استمع</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.ttsBtn, showTranslations[i] && { backgroundColor: COLORS.primary }]}
                      onPress={() => ensureTranslation(i)}
                      testID={`chat-translate-${i}`}
                    >
                      <Ionicons
                        name={showTranslations[i] ? "eye-off" : "language"}
                        size={14}
                        color={showTranslations[i] ? COLORS.textInverse : COLORS.textPrimary}
                      />
                      <Text style={[
                        styles.ttsBtnText,
                        showTranslations[i] && { color: COLORS.textInverse },
                      ]}>
                        {showTranslations[i] ? "إخفاء" : "ترجمة"}
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.ttsBtn, { backgroundColor: COLORS.warning }]}
                      onPress={() => suggestReply(m.text)}
                      testID={`chat-suggest-${i}`}
                    >
                      <Ionicons name="bulb" size={14} color={COLORS.textInverse} />
                      <Text style={[styles.ttsBtnText, { color: COLORS.textInverse }]}>
                        اجابة
                      </Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            </View>
          ))}
          {sending && (
            <View style={[styles.bubble, styles.bubbleBot, NEO_SHADOW_SM]}>
              <ActivityIndicator size="small" color={COLORS.primary} />
            </View>
          )}
        </ScrollView>

        {/* Quick suggestions */}
        {showSuggestions && (
          <View style={styles.suggestions} testID="chat-suggestions">
            {lastMsg.suggestions!.map((s, i) => (
              <TouchableOpacity
                key={i}
                testID={`chat-suggestion-${i}`}
                style={[styles.suggestionChip, NEO_SHADOW_SM]}
                onPress={() => send(s)}
                activeOpacity={0.85}
              >
                <Text style={styles.suggestionText}>{s}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        <View style={styles.inputBar}>
          <TextInput
            testID="chat-input"
            style={styles.input}
            value={input}
            onChangeText={setInput}
            placeholder={recording ? "🔴 يتم التسجيل... اضغط الميكروفون للإنهاء" : (transcribing ? "⏳ جاري التحويل..." : "Type in English...")}
            placeholderTextColor={COLORS.placeholder}
            multiline
            editable={!recording && !transcribing}
            onSubmitEditing={() => send()}
          />
          <TouchableOpacity
            testID="chat-mic"
            style={[
              styles.micBtn,
              NEO_SHADOW_SM,
              recording && { backgroundColor: COLORS.error },
              transcribing && { opacity: 0.6 },
            ]}
            onPress={toggleRecording}
            disabled={transcribing || sending}
          >
            <Ionicons
              name={recording ? "stop" : "mic"}
              size={20}
              color={COLORS.textInverse}
            />
          </TouchableOpacity>
          <TouchableOpacity
            testID="chat-send"
            style={[styles.sendBtn, NEO_SHADOW_SM, (sending || recording) && { opacity: 0.5 }]}
            onPress={() => send()}
            disabled={sending || recording || transcribing}
          >
            <Ionicons name="send" size={18} color={COLORS.textInverse} />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>

      {/* Scenario + Level Picker Modal */}
      <Modal visible={pickerOpen} transparent animationType="slide" onRequestClose={() => setPickerOpen(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setPickerOpen(false)}>
          <Pressable style={[styles.modalSheet, NEO_SHADOW]} onPress={(e) => e.stopPropagation()}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>اختر السيناريو</Text>
            <View style={styles.scenarioGrid}>
              {scenarios.map(sc => (
                <TouchableOpacity
                  key={sc.id}
                  testID={`scenario-${sc.id}`}
                  style={[
                    styles.scenarioCard,
                    NEO_SHADOW_SM,
                    scenario === sc.id && { backgroundColor: COLORS.primary, borderColor: COLORS.textPrimary },
                  ]}
                  onPress={() => setScenario(sc.id)}
                >
                  <Text style={styles.scenarioEmoji}>{sc.emoji}</Text>
                  <Text style={[
                    styles.scenarioLabel,
                    scenario === sc.id && { color: COLORS.textInverse },
                  ]}>{sc.name_ar}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.modalTitle}>المستوى</Text>
            <View style={styles.levelRow}>
              {LEVELS.map(lv => (
                <TouchableOpacity
                  key={lv.id}
                  testID={`level-${lv.id}`}
                  style={[
                    styles.levelChip,
                    NEO_SHADOW_SM,
                    level === lv.id && { backgroundColor: COLORS.primary },
                  ]}
                  onPress={() => setLevel(lv.id)}
                >
                  <Text style={[
                    styles.levelChipText,
                    level === lv.id && { color: COLORS.textInverse },
                  ]}>{lv.label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity
              testID="picker-confirm"
              style={[styles.confirmBtn, NEO_SHADOW]}
              onPress={() => { setPickerOpen(false); resetChat(); }}
            >
              <Text style={styles.confirmBtnText}>ابدأ المحادثة</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Word Translation Modal */}
      <Modal visible={!!translateModal} transparent animationType="fade" onRequestClose={() => setTranslateModal(null)}>
        <Pressable style={styles.modalOverlay} onPress={() => setTranslateModal(null)}>
          <Pressable style={[styles.translateCard, NEO_SHADOW]} onPress={(e) => e.stopPropagation()}>
            <Text style={styles.translateLabel}>الكلمة</Text>
            <Text style={styles.translateWord}>{translateModal?.word}</Text>
            <View style={styles.translateDivider} />
            <Text style={styles.translateLabel}>الترجمة</Text>
            {translateModal?.loading ? (
              <ActivityIndicator color={COLORS.primary} style={{ marginTop: 8 }} />
            ) : (
              <Text style={styles.translateResult}>{translateModal?.result}</Text>
            )}
            <View style={styles.translateActions}>
              <TouchableOpacity
                style={[styles.translateBtn, NEO_SHADOW_SM, { backgroundColor: COLORS.surface2 }]}
                onPress={() => translateModal && playTTS(translateModal.word)}
                testID="translate-tts"
              >
                <Ionicons name="volume-high" size={16} color={COLORS.textPrimary} />
                <Text style={styles.translateBtnText}>استمع</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.translateBtn, NEO_SHADOW_SM, { backgroundColor: COLORS.primary }]}
                onPress={() => setTranslateModal(null)}
                testID="translate-close"
              >
                <Text style={[styles.translateBtnText, { color: COLORS.textInverse }]}>إغلاق</Text>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Suggest Reply Modal */}
      <Modal
        visible={!!suggestModal}
        transparent
        animationType="fade"
        onRequestClose={() => setSuggestModal(null)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setSuggestModal(null)}>
          <Pressable style={[styles.translateCard, NEO_SHADOW]} onPress={(e) => e.stopPropagation()}>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8, marginBottom: 4 }}>
              <Ionicons name="bulb" size={20} color={COLORS.warning} />
              <Text style={[styles.translateLabel, { fontSize: 14 }]}>إجابة مقترحة لك</Text>
            </View>
            {suggestModal?.loading ? (
              <ActivityIndicator color={COLORS.warning} style={{ marginVertical: 24 }} />
            ) : (
              <>
                <Text style={[styles.translateWord, { fontSize: 18, marginTop: 10 }]}>
                  {suggestModal?.reply_en || "—"}
                </Text>
                <View style={styles.translateDivider} />
                <Text style={styles.translateLabel}>الترجمة</Text>
                <Text style={styles.translateResult}>{suggestModal?.reply_ar || ""}</Text>
                <View style={[styles.translateActions, { flexWrap: "wrap" }]}>
                  <TouchableOpacity
                    style={[styles.translateBtn, NEO_SHADOW_SM, { backgroundColor: COLORS.surface2 }]}
                    onPress={() => suggestModal?.reply_en && playTTS(suggestModal.reply_en)}
                    testID="suggest-tts"
                  >
                    <Ionicons name="volume-high" size={16} color={COLORS.textPrimary} />
                    <Text style={styles.translateBtnText}>استمع</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.translateBtn, NEO_SHADOW_SM, { backgroundColor: COLORS.surface2 }]}
                    onPress={() => useSuggestedReply(false)}
                    testID="suggest-fill"
                    disabled={!suggestModal?.reply_en}
                  >
                    <Ionicons name="create" size={16} color={COLORS.textPrimary} />
                    <Text style={styles.translateBtnText}>تعديل</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.translateBtn, NEO_SHADOW_SM, { backgroundColor: COLORS.success }]}
                    onPress={() => useSuggestedReply(true)}
                    testID="suggest-send"
                    disabled={!suggestModal?.reply_en}
                  >
                    <Ionicons name="send" size={16} color={COLORS.textInverse} />
                    <Text style={[styles.translateBtnText, { color: COLORS.textInverse }]}>أرسل</Text>
                  </TouchableOpacity>
                </View>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    padding: 12,
    gap: 8,
    borderBottomWidth: 2,
    borderBottomColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  avatar: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },
  headerTitle: { fontWeight: "900", fontSize: 14, color: COLORS.textPrimary, textAlign: "right" },
  headerSub: { fontSize: 12, color: COLORS.primary, fontWeight: "700", textAlign: "right", marginTop: 2 },
  iconBtn: {
    width: 38, height: 38, borderRadius: 10,
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },

  messages: { padding: 16, gap: 14 },
  bubble: {
    padding: 12,
    borderRadius: 16,
    maxWidth: "88%",
    borderWidth: 2,
    borderColor: COLORS.border,
  },
  bubbleUser: {
    alignSelf: "flex-start",
    backgroundColor: COLORS.primary,
    borderBottomLeftRadius: 4,
  },
  bubbleBot: {
    alignSelf: "flex-end",
    backgroundColor: COLORS.surface,
    borderBottomRightRadius: 4,
  },
  wordsRow: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  wordText: { fontSize: 15, color: COLORS.textPrimary, lineHeight: 22, fontWeight: "600" },
  wordTextUser: { color: COLORS.textInverse },
  bubbleArabic: {
    fontSize: 13,
    color: COLORS.textSecondary,
    marginTop: 6,
    textAlign: "right",
    fontWeight: "500",
  },
  ttsBtn: {
    flexDirection: "row-reverse", alignItems: "center", gap: 4,
    backgroundColor: COLORS.surface2,
    paddingHorizontal: 10, paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1.5, borderColor: COLORS.border,
  },
  bubbleActions: {
    flexDirection: "row-reverse",
    gap: 6,
    marginTop: 8,
    flexWrap: "wrap",
  },
  ttsBtnText: { fontSize: 11, fontWeight: "800", color: COLORS.textPrimary },

  correctionCard: {
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.warning,
    borderRadius: 12,
    padding: 10,
    marginBottom: 6,
    alignSelf: "flex-end",
    maxWidth: "92%",
  },
  correctionHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 6, marginBottom: 6 },
  correctionTitle: { fontSize: 11, fontWeight: "900", color: COLORS.warning, letterSpacing: 1 },
  correctionRow: { fontSize: 13, marginBottom: 2, textAlign: "right" },
  correctionLabel: { fontWeight: "800", color: COLORS.textSecondary },
  correctionWrong: { color: COLORS.error, fontWeight: "800", textDecorationLine: "line-through" },
  correctionRight: { color: COLORS.success, fontWeight: "800" },
  correctionExplain: { fontSize: 12, color: COLORS.textPrimary, marginTop: 4, textAlign: "right" },

  suggestions: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: 12,
    paddingTop: 8,
    paddingBottom: 4,
    gap: 8,
  },
  suggestionChip: {
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    paddingHorizontal: 12, paddingVertical: 8,
    borderRadius: 999,
  },
  suggestionText: { fontSize: 13, fontWeight: "700", color: COLORS.textPrimary },

  inputBar: {
    flexDirection: "row-reverse",
    alignItems: "flex-end",
    padding: 10,
    gap: 8,
    borderTopWidth: 2,
    borderTopColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  input: {
    flex: 1,
    backgroundColor: COLORS.bg,
    borderWidth: 2,
    borderColor: COLORS.border,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
    color: COLORS.textPrimary,
    maxHeight: 120,
    minHeight: 44,
  },
  sendBtn: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: COLORS.primary,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },
  micBtn: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: COLORS.success,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },

  // Modal scenario picker
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.65)",
    justifyContent: "flex-end",
  },
  modalSheet: {
    backgroundColor: COLORS.surface,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 2, borderColor: COLORS.border,
    padding: 20,
    gap: 14,
  },
  modalHandle: {
    width: 50, height: 4, borderRadius: 2,
    backgroundColor: COLORS.border,
    alignSelf: "center",
    marginBottom: 6,
  },
  modalTitle: { fontSize: 16, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right" },
  scenarioGrid: {
    flexDirection: "row-reverse",
    flexWrap: "wrap",
    gap: 10,
  },
  scenarioCard: {
    width: "31%",
    aspectRatio: 1,
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 14,
    alignItems: "center", justifyContent: "center",
    gap: 4,
  },
  scenarioEmoji: { fontSize: 30 },
  scenarioLabel: { fontSize: 12, fontWeight: "800", color: COLORS.textPrimary, textAlign: "center" },

  levelRow: { flexDirection: "row-reverse", gap: 10 },
  levelChip: {
    flex: 1,
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: "center",
  },
  levelChipText: { fontSize: 14, fontWeight: "900", color: COLORS.textPrimary },

  confirmBtn: {
    backgroundColor: COLORS.primary,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 14,
    padding: 14,
    alignItems: "center",
    marginTop: 4,
  },
  confirmBtnText: { fontWeight: "900", fontSize: 16, color: COLORS.textInverse },

  // Translate modal
  translateCard: {
    backgroundColor: COLORS.surface,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 22,
    padding: 22,
    margin: 28,
    alignSelf: "center",
    minWidth: 280,
  },
  translateLabel: { fontSize: 11, fontWeight: "900", color: COLORS.textSecondary, letterSpacing: 1, textAlign: "center" },
  translateWord: { fontSize: 32, fontWeight: "900", color: COLORS.primary, textAlign: "center", marginTop: 4 },
  translateResult: { fontSize: 28, fontWeight: "900", color: COLORS.textPrimary, textAlign: "center", marginTop: 6 },
  translateDivider: { height: 1.5, backgroundColor: COLORS.border, marginVertical: 14 },
  translateActions: { flexDirection: "row-reverse", gap: 10, marginTop: 18 },
  translateBtn: {
    flex: 1,
    flexDirection: "row-reverse",
    alignItems: "center", justifyContent: "center",
    gap: 6,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 12,
    paddingVertical: 12,
  },
  translateBtnText: { fontWeight: "900", color: COLORS.textPrimary, fontSize: 14 },
});
