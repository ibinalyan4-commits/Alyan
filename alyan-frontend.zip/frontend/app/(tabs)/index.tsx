import { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useRouter, useFocusEffect } from "expo-router";
import { useCallback } from "react";
import { COLORS, NEO_SHADOW, NEO_SHADOW_SM, BACKEND_URL } from "../../constants/theme";
import { getUser } from "../../utils/user";
import { useResponsive } from "../../utils/responsive";
import AdBanner from "../../components/AdBanner";

type Progress = {
  user_id: string;
  xp: number;
  streak: number;
  lessons_completed: string[];
  level: number;
};

type Category = {
  id: string;
  name_en: string;
  name_ar: string;
  emoji: string;
  color: string;
  description_ar: string;
  word_count: number;
};

export default function Home() {
  const router = useRouter();
  const [progress, setProgress] = useState<Progress | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [userName, setUserName] = useState<string>("");
  const responsive = useResponsive();
  const [userId, setUserId] = useState<string>("default");

  const load = useCallback(async () => {
    try {
      const u = await getUser();
      const uid = u?.userId || "default";
      if (u?.name) setUserName(u.name);
      setUserId(uid);
      const [pRes, cRes] = await Promise.all([
        fetch(`${BACKEND_URL}/api/progress/${uid}`),
        fetch(`${BACKEND_URL}/api/categories`),
      ]);
      const p = await pRes.json();
      const c = await cRes.json();
      setProgress(p);
      setCategories(c);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const xpToNext = ((progress?.level || 1) * 100);
  const xpProgress = progress ? (progress.xp % 100) : 0;
  const dailyCategory = categories[0];

  if (loading) {
    return (
      <SafeAreaView style={styles.safe}>
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 100 }} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <AdBanner />
      <ScrollView
        contentContainerStyle={[styles.container, { padding: responsive.pad }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ width: "100%", maxWidth: responsive.contentMaxWidth, alignSelf: "center" }}>
        {/* AI Teacher Banner - عليان */}
        <TouchableOpacity
          activeOpacity={0.9}
          style={[styles.teacherBanner, NEO_SHADOW]}
          onPress={() => router.push("/(tabs)/chat")}
          testID="teacher-banner"
        >
          <View style={styles.teacherFlag}>
            <Text style={styles.teacherFlagEmoji}>🇸🇦</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.teacherLabel}>المعلم الذكي</Text>
            <Text style={styles.teacherName}>عليان</Text>
            <Text style={styles.teacherTagline}>تعلّم الإنجليزية بالذكاء الاصطناعي ✨</Text>
          </View>
          <View style={styles.teacherCta}>
            <Ionicons name="chatbubbles" size={22} color={COLORS.textInverse} />
          </View>
        </TouchableOpacity>

        {/* Header */}
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={styles.greeting}>أهلاً 👋</Text>
            <Text style={styles.title}>{userName ? userName : "هيا نتعلم!"}</Text>
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity
              testID="open-leaderboard"
              style={[styles.iconBtn, NEO_SHADOW_SM]}
              onPress={() => router.push("/leaderboard")}
            >
              <Ionicons name="trophy" size={20} color={COLORS.warning} />
            </TouchableOpacity>
            <TouchableOpacity
              testID="open-settings"
              style={[styles.iconBtn, NEO_SHADOW_SM]}
              onPress={() => router.push("/settings")}
            >
              <Ionicons name="settings" size={20} color={COLORS.textPrimary} />
            </TouchableOpacity>
            <View style={[styles.streakBadge, NEO_SHADOW_SM]} testID="streak-badge">
              <Ionicons name="flame" size={18} color={COLORS.warning} />
              <Text style={styles.streakText}>{progress?.streak || 0}</Text>
            </View>
          </View>
        </View>

        {/* XP Card */}
        <View style={[styles.xpCard, NEO_SHADOW]} testID="xp-card">
          <View style={styles.xpRow}>
            <View style={styles.levelCircle}>
              <Text style={styles.levelText}>{progress?.level || 1}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.xpLabel}>المستوى {progress?.level || 1}</Text>
              <Text style={styles.xpValue}>{progress?.xp || 0} نقطة</Text>
              <View style={styles.progressBarOuter}>
                <View style={[styles.progressBarInner, { width: `${xpProgress}%` }]} />
              </View>
              <Text style={styles.xpHint}>
                {100 - xpProgress} نقطة للوصول للمستوى التالي
              </Text>
            </View>
          </View>
        </View>

        {/* Daily Lesson CTA */}
        {dailyCategory && (
          <TouchableOpacity
            testID="daily-lesson-cta"
            activeOpacity={0.85}
            style={[styles.dailyCard, NEO_SHADOW, { backgroundColor: COLORS.primary }]}
            onPress={() => router.push(`/lesson/${dailyCategory.id}`)}
          >
            <View style={{ flex: 1 }}>
              <Text style={styles.dailyLabel}>درس اليوم</Text>
              <Text style={styles.dailyTitle}>{dailyCategory.name_ar}</Text>
              <Text style={styles.dailySub}>{dailyCategory.description_ar}</Text>
              <View style={styles.dailyButton}>
                <Text style={styles.dailyButtonText}>ابدأ الآن</Text>
                <Ionicons name="arrow-back" size={18} color={COLORS.textPrimary} />
              </View>
            </View>
            <Text style={styles.dailyEmoji}>{dailyCategory.emoji}</Text>
          </TouchableOpacity>
        )}

        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>تعلم بطريقتك</Text>
        <View style={styles.quickGrid}>
          <QuickAction
            testID="quick-pictures"
            icon="image"
            label="بالصور"
            color={COLORS.sky}
            onPress={() => router.push("/pictures")}
          />
          <QuickAction
            testID="quick-quiz"
            icon="help-circle"
            label="اختبار"
            color={COLORS.success}
            onPress={() => router.push(`/quiz/${dailyCategory?.id || "greetings"}`)}
          />
          <QuickAction
            testID="quick-chat"
            icon="chatbubbles"
            label="محادثة AI"
            color={COLORS.pink}
            onPress={() => router.push("/chat")}
          />
          <QuickAction
            testID="quick-flashcards"
            icon="albums"
            label="بطاقات"
            color={COLORS.warning}
            onPress={() => router.push("/flashcards")}
          />
        </View>

        <View style={{ height: 24 }} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function QuickAction({ icon, label, color, onPress, testID }: any) {
  return (
    <TouchableOpacity
      testID={testID}
      activeOpacity={0.85}
      style={[styles.quickItem, NEO_SHADOW_SM, { backgroundColor: color }]}
      onPress={onPress}
    >
      <Ionicons name={icon} size={28} color={COLORS.textPrimary} />
      <Text style={styles.quickLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  container: { padding: 20, paddingBottom: 32 },
  teacherBanner: {
    flexDirection: "row-reverse",
    alignItems: "center",
    backgroundColor: COLORS.surface2,
    borderWidth: 2,
    borderColor: COLORS.border,
    borderRadius: 18,
    padding: 14,
    gap: 12,
    marginBottom: 18,
  },
  teacherFlag: {
    width: 56,
    height: 56,
    borderRadius: 14,
    backgroundColor: COLORS.surface,
    borderWidth: 2,
    borderColor: COLORS.border,
    alignItems: "center",
    justifyContent: "center",
  },
  teacherFlagEmoji: { fontSize: 30 },
  teacherLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontWeight: "700",
    textAlign: "right",
    letterSpacing: 0.5,
  },
  teacherName: {
    fontSize: 32,
    color: COLORS.textPrimary,
    fontWeight: "900",
    textAlign: "right",
    letterSpacing: 1,
    marginTop: 2,
  },
  teacherTagline: {
    fontSize: 11,
    color: COLORS.textSecondary,
    fontWeight: "600",
    textAlign: "right",
    marginTop: 2,
  },
  teacherCta: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: COLORS.primary,
    borderWidth: 2,
    borderColor: COLORS.border,
    alignItems: "center",
    justifyContent: "center",
  },
  header: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  greeting: { fontSize: 16, color: COLORS.textSecondary, fontWeight: "800", textAlign: "right" },
  title: { fontSize: 30, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right", letterSpacing: 0.5 },
  streakBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: COLORS.surface2,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: COLORS.border,
    gap: 4,
  },
  streakText: { fontSize: 16, fontWeight: "900", color: COLORS.textPrimary },
  headerActions: { flexDirection: "row-reverse", alignItems: "center", gap: 8 },
  iconBtn: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },
  xpCard: {
    backgroundColor: COLORS.surface,
    borderWidth: 2,
    borderColor: COLORS.border,
    borderRadius: 20,
    padding: 18,
    marginBottom: 18,
  },
  xpRow: { flexDirection: "row-reverse", alignItems: "center", gap: 14 },
  levelCircle: {
    width: 64, height: 64, borderRadius: 32,
    backgroundColor: COLORS.primary,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },
  levelText: { fontSize: 26, fontWeight: "900", color: COLORS.textInverse },
  xpLabel: { fontSize: 12, color: COLORS.textSecondary, fontWeight: "700", textAlign: "right" },
  xpValue: { fontSize: 22, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right" },
  progressBarOuter: {
    height: 14,
    backgroundColor: COLORS.muted,
    borderRadius: 999,
    borderWidth: 2,
    borderColor: COLORS.border,
    marginTop: 8,
    overflow: "hidden",
  },
  progressBarInner: {
    height: "100%",
    backgroundColor: COLORS.success,
  },
  xpHint: { fontSize: 11, color: COLORS.textSecondary, marginTop: 6, textAlign: "right", fontWeight: "600" },

  dailyCard: {
    flexDirection: "row-reverse",
    alignItems: "center",
    borderWidth: 2,
    borderColor: COLORS.border,
    borderRadius: 22,
    padding: 20,
    marginBottom: 22,
  },
  dailyLabel: { color: COLORS.textInverse, opacity: 0.7, fontSize: 12, fontWeight: "800", textAlign: "right" },
  dailyTitle: { color: COLORS.textInverse, fontSize: 28, fontWeight: "900", textAlign: "right" },
  dailySub: { color: COLORS.textInverse, opacity: 0.7, fontSize: 13, marginTop: 4, textAlign: "right" },
  dailyButton: {
    marginTop: 14,
    flexDirection: "row-reverse",
    alignItems: "center",
    alignSelf: "flex-end",
    backgroundColor: COLORS.surface,
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: COLORS.border,
    gap: 8,
  },
  dailyButtonText: { fontWeight: "900", color: COLORS.textPrimary, fontSize: 14 },
  dailyEmoji: { fontSize: 60, marginEnd: 12 },

  sectionTitle: {
    fontSize: 20,
    fontWeight: "900",
    color: COLORS.textPrimary,
    marginBottom: 12,
    textAlign: "right",
    letterSpacing: 0.5,
  },
  quickGrid: {
    flexDirection: "row-reverse",
    flexWrap: "wrap",
    gap: 12,
  },
  quickItem: {
    width: "48%",
    aspectRatio: 1.6,
    borderWidth: 2,
    borderColor: COLORS.border,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  quickLabel: { fontWeight: "900", color: COLORS.textPrimary, fontSize: 17, letterSpacing: 0.3 },
});
