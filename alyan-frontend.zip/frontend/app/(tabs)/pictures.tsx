import { useEffect, useState, useCallback } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, ScrollView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { COLORS, NEO_SHADOW, NEO_SHADOW_SM, BACKEND_URL } from "../../constants/theme";
import { playTTS } from "../../utils/audio";
import { getUser } from "../../utils/user";
import Celebration from "../../components/Celebration";
import AdBanner from "../../components/AdBanner";

type Item = {
  id: string;
  emoji: string;
  options: string[];
  category: string;
  correct_en: string;
  correct_ar: string;
};

const CATEGORIES = [
  { id: "all", name: "الكل", emoji: "🎯" },
  { id: "animals", name: "حيوانات", emoji: "🐾" },
  { id: "food", name: "طعام", emoji: "🍔" },
  { id: "transport", name: "مواصلات", emoji: "🚗" },
  { id: "nature", name: "طبيعة", emoji: "🌳" },
  { id: "objects", name: "أشياء", emoji: "📱" },
];

export default function Pictures() {
  const [category, setCategory] = useState<string>("all");
  const [item, setItem] = useState<Item | null>(null);
  const [token, setToken] = useState<string>("");
  const [selected, setSelected] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);
  const [celebrate, setCelebrate] = useState(false);
  const [totalCorrect, setTotalCorrect] = useState(0);
  const [totalAnswered, setTotalAnswered] = useState(0);
  const [xpEarned, setXpEarned] = useState(0);

  const loadItem = useCallback(async (cat: string) => {
    setLoading(true);
    setSelected(null); setSubmitted(false);
    try {
      const url = `${BACKEND_URL}/api/picture-quiz?count=1${cat !== "all" ? `&category=${cat}` : ""}`;
      const data = await fetch(url).then(r => r.json());
      if (data.items?.length) {
        setItem(data.items[0]);
        setToken(data.token || "");
      }
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { loadItem(category); }, [category, loadItem]);

  const submit = async () => {
    if (!selected || !item || submitting) return;
    setSubmitting(true);
    setSubmitted(true);
    const isCorrect = selected === item.correct_en;
    setTotalAnswered(n => n + 1);
    if (isCorrect) {
      setTotalCorrect(n => n + 1);
      setCelebrate(true);
      setTimeout(() => playTTS(item.correct_en), 100);
    }
    try {
      const u = await getUser();
      const uid = u?.userId || "default";
      const res = await fetch(`${BACKEND_URL}/api/picture-quiz/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: uid,
          name: u?.name || "",
          token,
          answers: [selected],
        }),
      });
      const data = await res.json();
      if (res.ok && data.xp_awarded) {
        setXpEarned(x => x + data.xp_awarded);
      }
    } catch (e) { console.error(e); }
    setSubmitting(false);
  };

  const nextPicture = () => {
    loadItem(category);
  };

  if (loading || !item) {
    return (
      <SafeAreaView style={styles.safe}>
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 100 }} />
      </SafeAreaView>
    );
  }

  const isCorrect = submitted && selected === item.correct_en;

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <AdBanner testID="pictures-ad" />
      <View style={styles.headerWrap}>
        <View style={styles.headerRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.title}>تعلم بالصور</Text>
            <Text style={styles.subtitle}>اختر الكلمة الإنجليزية الصحيحة</Text>
          </View>
          <View style={[styles.statBadge, NEO_SHADOW_SM]} testID="pic-stat">
            <Ionicons name="trophy" size={14} color={COLORS.warning} />
            <Text style={styles.statText}>{totalCorrect}/{totalAnswered}</Text>
            <Text style={styles.statXp}>+{xpEarned}</Text>
          </View>
        </View>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.catRow}
          style={{ marginTop: 12 }}
        >
          {CATEGORIES.map(c => (
            <TouchableOpacity
              key={c.id}
              testID={`pic-cat-${c.id}`}
              style={[
                styles.catChip,
                NEO_SHADOW_SM,
                category === c.id && { backgroundColor: COLORS.primary },
              ]}
              onPress={() => setCategory(c.id)}
            >
              <Text style={styles.catEmoji}>{c.emoji}</Text>
              <Text style={[
                styles.catText,
                category === c.id && { color: COLORS.textInverse },
              ]}>{c.name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <ScrollView contentContainerStyle={styles.body} showsVerticalScrollIndicator={false}>
        <View style={[styles.imageCard, NEO_SHADOW]}>
          <Text style={styles.bigEmoji}>{item.emoji}</Text>
          <Text style={styles.imageHint}>ما اسم هذا بالإنجليزية؟</Text>
        </View>

        <View style={styles.optionsGrid}>
          {item.options.map((opt, i) => {
            const isSelected = selected === opt;
            const showCorrect = submitted && opt === item.correct_en;
            const showWrong = submitted && isSelected && opt !== item.correct_en;
            return (
              <View key={i} style={styles.optionRow}>
                <TouchableOpacity
                  testID={`pic-option-${i}`}
                  disabled={submitted}
                  activeOpacity={0.85}
                  style={[
                    styles.option,
                    NEO_SHADOW_SM,
                    isSelected && !submitted && { backgroundColor: COLORS.primary },
                    showCorrect && { backgroundColor: COLORS.success, borderColor: COLORS.textPrimary },
                    showWrong && { backgroundColor: COLORS.error, borderColor: COLORS.textPrimary },
                  ]}
                  onPress={() => setSelected(opt)}
                >
                  <Text style={[
                    styles.optionText,
                    (isSelected && !submitted) && { color: COLORS.textInverse },
                    (showCorrect || showWrong) && { color: COLORS.textInverse },
                  ]}>{opt}</Text>
                  {showCorrect && <Ionicons name="checkmark-circle" size={26} color={COLORS.textInverse} />}
                  {showWrong && <Ionicons name="close-circle" size={26} color={COLORS.textInverse} />}
                </TouchableOpacity>
                <TouchableOpacity
                  testID={`pic-listen-${i}`}
                  style={[styles.listenIcon, NEO_SHADOW_SM]}
                  onPress={() => playTTS(opt)}
                  activeOpacity={0.7}
                >
                  <Ionicons name="volume-high" size={20} color={COLORS.textInverse} />
                </TouchableOpacity>
              </View>
            );
          })}
        </View>

        {submitted && (
          <View style={[styles.feedback, isCorrect ? styles.fbOk : styles.fbBad, NEO_SHADOW_SM]}>
            <Text style={styles.feedbackText}>
              {isCorrect
                ? `✅ صحيح! ${item.correct_en} = ${item.correct_ar} (+5 نقاط)`
                : `❌ الصحيح: ${item.correct_en} = ${item.correct_ar}`
              }
            </Text>
          </View>
        )}
      </ScrollView>

      <View style={styles.footer}>
        {!submitted ? (
          <TouchableOpacity
            testID="pic-submit"
            disabled={!selected || submitting}
            style={[styles.actionBtn, NEO_SHADOW, (!selected || submitting) && { opacity: 0.4 }]}
            onPress={submit}
            activeOpacity={0.85}
          >
            <Text style={styles.actionText}>تحقق</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            testID="pic-next"
            disabled={celebrate}
            style={[styles.actionBtn, NEO_SHADOW, { backgroundColor: COLORS.success }, celebrate && { opacity: 0.5 }]}
            onPress={nextPicture}
            activeOpacity={0.85}
          >
            <Ionicons name="arrow-back" size={20} color={COLORS.textInverse} />
            <Text style={styles.actionText}>{celebrate ? "🎉 رائع..." : "الصورة التالية"}</Text>
          </TouchableOpacity>
        )}
      </View>

      <Celebration visible={celebrate} onDone={() => setCelebrate(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  headerWrap: { paddingHorizontal: 20, paddingTop: 12 },
  headerRow: { flexDirection: "row-reverse", alignItems: "center", gap: 12 },
  title: { fontSize: 28, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right", letterSpacing: 0.5 },
  subtitle: { fontSize: 14, color: COLORS.textSecondary, marginTop: 4, textAlign: "right", fontWeight: "700" },

  statBadge: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    paddingHorizontal: 10, paddingVertical: 8,
    borderRadius: 12,
  },
  statText: { fontWeight: "900", color: COLORS.textPrimary, fontSize: 13 },
  statXp: { fontWeight: "900", color: COLORS.warning, fontSize: 13 },

  catRow: { gap: 10, paddingVertical: 4 },
  catChip: {
    flexDirection: "row-reverse",
    alignItems: "center",
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    paddingHorizontal: 14, paddingVertical: 8,
    borderRadius: 999,
    gap: 6,
  },
  catEmoji: { fontSize: 16 },
  catText: { fontSize: 14, fontWeight: "900", color: COLORS.textPrimary },

  body: { padding: 20, paddingBottom: 30 },
  imageCard: {
    backgroundColor: COLORS.surface,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 24,
    padding: 36,
    alignItems: "center",
    marginBottom: 22,
  },
  bigEmoji: { fontSize: 130, lineHeight: 150 },
  imageHint: { fontSize: 14, color: COLORS.textSecondary, marginTop: 10, fontWeight: "800" },

  optionsGrid: { gap: 12 },
  optionRow: { flexDirection: "row-reverse", gap: 10, alignItems: "stretch" },
  option: {
    flex: 1,
    backgroundColor: COLORS.surface,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 16,
    paddingVertical: 18, paddingHorizontal: 18,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
  },
  optionText: { fontSize: 22, fontWeight: "900", color: COLORS.textPrimary, letterSpacing: 0.5 },
  listenIcon: {
    width: 60,
    backgroundColor: COLORS.primary,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 16,
    alignItems: "center", justifyContent: "center",
  },

  feedback: {
    marginTop: 18, padding: 14,
    borderRadius: 14, borderWidth: 2, borderColor: COLORS.border,
  },
  fbOk: { backgroundColor: COLORS.success },
  fbBad: { backgroundColor: COLORS.warning },
  feedbackText: { fontSize: 15, fontWeight: "900", color: COLORS.textInverse, textAlign: "right" },

  footer: {
    padding: 16,
    borderTopWidth: 2, borderTopColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  actionBtn: {
    flexDirection: "row-reverse",
    alignItems: "center", justifyContent: "center",
    gap: 8,
    backgroundColor: COLORS.primary,
    borderRadius: 16,
    borderWidth: 2, borderColor: COLORS.border,
    padding: 18,
  },
  actionText: { color: COLORS.textInverse, fontWeight: "900", fontSize: 18 },
});
