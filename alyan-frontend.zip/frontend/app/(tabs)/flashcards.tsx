import { useEffect, useState, useRef } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Animated,
  Modal, Pressable,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { COLORS, NEO_SHADOW, BACKEND_URL } from "../../constants/theme";
import { playTTS, prefetchTTS } from "../../utils/audio";
import AdBanner from "../../components/AdBanner";

type Sentence = { en: string; ar: string };

export default function Flashcards() {
  const [items, setItems] = useState<Sentence[]>([]);
  const [idx, setIdx] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [loading, setLoading] = useState(true);
  const [translateModal, setTranslateModal] = useState<{ word: string; result: string; loading: boolean } | null>(null);
  const flipAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${BACKEND_URL}/api/quick-sentences`);
        const data = await res.json();
        const list: Sentence[] = data?.sentences || [];
        setItems(list);
        // Pre-warm TTS cache for first 3 sentences (faster playback later)
        list.slice(0, 3).forEach((s) => prefetchTTS(s.en));
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // Pre-fetch the upcoming sentence's TTS to make audio feel instant
  useEffect(() => {
    if (!items.length) return;
    const nextIdx = (idx + 1) % items.length;
    prefetchTTS(items[nextIdx]?.en);
  }, [idx, items]);

  const flip = () => {
    Animated.spring(flipAnim, {
      toValue: flipped ? 0 : 1,
      useNativeDriver: true,
      friction: 8, tension: 40,
    }).start();
    setFlipped(!flipped);
  };

  const next = () => {
    flipAnim.setValue(0);
    setFlipped(false);
    setIdx((i) => (i + 1) % Math.max(1, items.length));
  };

  const prev = () => {
    flipAnim.setValue(0);
    setFlipped(false);
    setIdx((i) => (i - 1 + items.length) % Math.max(1, items.length));
  };

  const openTranslate = async (text: string) => {
    const cleaned = (text || "").trim();
    if (!cleaned) return;
    setTranslateModal({ word: cleaned, result: "", loading: true });
    try {
      const res = await fetch(`${BACKEND_URL}/api/translate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ word: cleaned }),
      });
      const data = await res.json();
      setTranslateModal({ word: cleaned, result: data.translation || "—", loading: false });
    } catch {
      setTranslateModal({ word: cleaned, result: "تعذرت الترجمة", loading: false });
    }
  };

  const frontInterpolate = flipAnim.interpolate({ inputRange: [0, 1], outputRange: ["0deg", "180deg"] });
  const backInterpolate = flipAnim.interpolate({ inputRange: [0, 1], outputRange: ["180deg", "360deg"] });

  if (loading) {
    return (
      <SafeAreaView style={styles.safe}>
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 100 }} />
      </SafeAreaView>
    );
  }

  if (!items.length) {
    return (
      <SafeAreaView style={styles.safe}>
        <Text style={styles.title}>لا توجد جمل</Text>
      </SafeAreaView>
    );
  }

  const s = items[idx];

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <AdBanner testID="flashcards-ad" />
      <View style={styles.headerWrap}>
        <Text style={styles.title}>جمل سريعة 💬</Text>
        <Text style={styles.subtitle}>عبارات يومية مفيدة — اضغط البطاقة للترجمة 👆</Text>
        <Text style={styles.counter}>{idx + 1} / {items.length}</Text>
      </View>

      <View style={styles.cardArea}>
        <TouchableOpacity activeOpacity={0.95} onPress={flip} testID="flashcard-flip">
          <View>
            <Animated.View
              style={[styles.card, NEO_SHADOW, styles.cardFront, {
                transform: [{ rotateY: frontInterpolate }],
              }]}
            >
              <Text style={styles.cardLabelEn}>ENGLISH</Text>
              <Text style={styles.cardSentenceEn}>{s.en}</Text>
              <View style={styles.actionsRow}>
                <TouchableOpacity
                  testID="flashcard-tts-front"
                  style={styles.speakBtn}
                  onPress={(e) => { e.stopPropagation(); playTTS(s.en); }}
                >
                  <Ionicons name="volume-high" size={20} color={COLORS.textInverse} />
                  <Text style={styles.speakBtnText}>استمع</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  testID="flashcard-translate-front"
                  style={styles.translateBtn}
                  onPress={(e) => { e.stopPropagation(); openTranslate(s.en); }}
                >
                  <Ionicons name="language" size={20} color={COLORS.textPrimary} />
                  <Text style={styles.translateBtnText}>ترجمة</Text>
                </TouchableOpacity>
              </View>
            </Animated.View>
            <Animated.View
              style={[styles.card, NEO_SHADOW, styles.cardBack, {
                transform: [{ rotateY: backInterpolate }],
              }]}
            >
              <Text style={styles.cardLabelAr}>العربية</Text>
              <Text style={styles.cardSentenceAr}>{s.ar}</Text>
              <Text style={styles.tapHint}>اضغط للعودة</Text>
            </Animated.View>
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.controls}>
        <TouchableOpacity
          testID="flashcard-prev"
          style={[styles.navBtn, NEO_SHADOW]}
          onPress={prev}
        >
          <Ionicons name="chevron-forward" size={28} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <TouchableOpacity
          testID="flashcard-next"
          style={[styles.navBtn, NEO_SHADOW, { backgroundColor: COLORS.primary }]}
          onPress={next}
        >
          <Ionicons name="chevron-back" size={28} color={COLORS.textInverse} />
        </TouchableOpacity>
      </View>

      {/* Translate modal */}
      <Modal
        visible={!!translateModal}
        transparent
        animationType="fade"
        onRequestClose={() => setTranslateModal(null)}
      >
        <Pressable style={styles.modalBackdrop} onPress={() => setTranslateModal(null)}>
          <Pressable style={[styles.modalCard, NEO_SHADOW]} onPress={(e) => e.stopPropagation()}>
            <View style={styles.modalHeader}>
              <Ionicons name="language" size={20} color={COLORS.primary} />
              <Text style={styles.modalTitle}>الترجمة</Text>
              <TouchableOpacity onPress={() => setTranslateModal(null)} testID="flashcard-translate-close">
                <Ionicons name="close" size={22} color={COLORS.textSecondary} />
              </TouchableOpacity>
            </View>
            <Text style={styles.modalEn} numberOfLines={3}>{translateModal?.word}</Text>
            <View style={styles.modalDivider} />
            {translateModal?.loading ? (
              <ActivityIndicator color={COLORS.primary} style={{ marginVertical: 16 }} />
            ) : (
              <Text style={styles.modalAr}>{translateModal?.result}</Text>
            )}
            <TouchableOpacity
              testID="flashcard-translate-listen"
              style={styles.modalListenBtn}
              onPress={() => translateModal && playTTS(translateModal.word)}
            >
              <Ionicons name="volume-high" size={18} color={COLORS.textInverse} />
              <Text style={styles.modalListenText}>استمع للجملة</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  headerWrap: { padding: 20, paddingBottom: 4 },
  title: { fontSize: 26, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right" },
  subtitle: { fontSize: 14, color: COLORS.textSecondary, marginTop: 4, textAlign: "right", fontWeight: "600" },
  counter: { fontSize: 13, color: COLORS.primary, fontWeight: "900", marginTop: 8, textAlign: "right" },
  cardArea: { flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: 24 },
  card: {
    width: 320,
    minHeight: 380,
    borderRadius: 24,
    borderWidth: 2,
    borderColor: COLORS.border,
    paddingVertical: 28,
    paddingHorizontal: 22,
    alignItems: "center",
    justifyContent: "center",
    backfaceVisibility: "hidden",
  },
  cardFront: { backgroundColor: COLORS.surface },
  cardBack: {
    backgroundColor: COLORS.warning,
    position: "absolute",
    top: 0, left: 0, right: 0, bottom: 0,
  },
  cardLabelEn: {
    fontSize: 11, fontWeight: "900", color: COLORS.primary, letterSpacing: 2,
    backgroundColor: "#FFE0CC", paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8,
    borderWidth: 1.5, borderColor: COLORS.border,
    marginBottom: 18,
  },
  cardSentenceEn: {
    fontSize: 30, fontWeight: "900", color: COLORS.textPrimary,
    textAlign: "center", lineHeight: 40,
    paddingHorizontal: 4,
  },
  cardLabelAr: {
    fontSize: 11, fontWeight: "900", color: COLORS.textPrimary, letterSpacing: 1,
    backgroundColor: COLORS.surface, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8,
    borderWidth: 1.5, borderColor: COLORS.border,
    marginBottom: 18,
  },
  cardSentenceAr: {
    fontSize: 30, fontWeight: "900", color: COLORS.textPrimary,
    textAlign: "center", lineHeight: 42,
  },
  tapHint: { fontSize: 12, color: COLORS.textPrimary, marginTop: 24, fontWeight: "700", opacity: 0.7 },
  speakBtn: {
    flexDirection: "row", alignItems: "center", gap: 8,
    backgroundColor: COLORS.primary,
    paddingHorizontal: 18, paddingVertical: 11,
    borderRadius: 14, borderWidth: 2, borderColor: COLORS.border,
  },
  speakBtnText: { color: COLORS.textInverse, fontWeight: "900", fontSize: 14 },
  translateBtn: {
    flexDirection: "row", alignItems: "center", gap: 8,
    backgroundColor: COLORS.surface,
    paddingHorizontal: 18, paddingVertical: 11,
    borderRadius: 14, borderWidth: 2, borderColor: COLORS.border,
  },
  translateBtnText: { color: COLORS.textPrimary, fontWeight: "900", fontSize: 14 },
  actionsRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 10,
    marginTop: 26,
    flexWrap: "wrap",
    justifyContent: "center",
  },
  controls: {
    flexDirection: "row-reverse",
    justifyContent: "center",
    gap: 18,
    paddingBottom: 20,
    paddingHorizontal: 24,
  },
  navBtn: {
    backgroundColor: COLORS.surface,
    width: 64, height: 64,
    borderRadius: 18,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  modalCard: {
    width: "100%",
    maxWidth: 380,
    backgroundColor: COLORS.surface,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: COLORS.border,
    padding: 20,
  },
  modalHeader: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 8,
    marginBottom: 12,
  },
  modalTitle: {
    flex: 1,
    fontSize: 16,
    fontWeight: "900",
    color: COLORS.textPrimary,
    textAlign: "right",
  },
  modalEn: {
    fontSize: 18,
    fontWeight: "700",
    color: COLORS.textPrimary,
    textAlign: "left",
    lineHeight: 26,
  },
  modalDivider: {
    height: 1,
    backgroundColor: COLORS.border,
    marginVertical: 14,
  },
  modalAr: {
    fontSize: 20,
    fontWeight: "800",
    color: COLORS.primary,
    textAlign: "right",
    lineHeight: 30,
  },
  modalListenBtn: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    backgroundColor: COLORS.primary,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: COLORS.border,
    marginTop: 18,
  },
  modalListenText: {
    color: COLORS.textInverse,
    fontWeight: "900",
    fontSize: 14,
  },
});
