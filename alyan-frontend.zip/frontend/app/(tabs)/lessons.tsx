import { useEffect, useState } from "react";
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { COLORS, NEO_SHADOW, BACKEND_URL } from "../../constants/theme";
import { useResponsive } from "../../utils/responsive";
import AdBanner from "../../components/AdBanner";

type Category = {
  id: string;
  name_en: string;
  name_ar: string;
  emoji: string;
  color: string;
  description_ar: string;
  word_count: number;
};

export default function Lessons() {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const responsive = useResponsive();

  useEffect(() => {
    fetch(`${BACKEND_URL}/api/categories`)
      .then(r => r.json())
      .then(setCategories)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <AdBanner testID="lessons-ad" />
      <View style={styles.headerWrap}>
        <Text style={styles.title}>الدروس</Text>
        <Text style={styles.subtitle}>اختر فئة وابدأ التعلم</Text>
      </View>
      {loading ? (
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 80 }} />
      ) : (
        <ScrollView
          contentContainerStyle={[styles.list, { padding: responsive.pad }]}
          showsVerticalScrollIndicator={false}
        >
          <View style={{ width: "100%", maxWidth: responsive.contentMaxWidth, alignSelf: "center" }}>
            {categories.map(cat => (
            <TouchableOpacity
              key={cat.id}
              testID={`category-${cat.id}`}
              activeOpacity={0.85}
              style={[styles.card, NEO_SHADOW, { backgroundColor: cat.color }]}
              onPress={() => router.push(`/lesson/${cat.id}`)}
            >
              <Text style={styles.emoji}>{cat.emoji}</Text>
              <View style={styles.cardBody}>
                <Text style={styles.cardTitle}>{cat.name_ar}</Text>
                <Text style={styles.cardEnglish}>{cat.name_en}</Text>
                <Text style={styles.cardDesc} numberOfLines={2}>{cat.description_ar}</Text>
                <View style={styles.metaRow}>
                  <View style={styles.metaPill}>
                    <Ionicons name="library" size={12} color={COLORS.textPrimary} />
                    <Text style={styles.metaText}>{cat.word_count} كلمة</Text>
                  </View>
                </View>
              </View>
              <Ionicons name="chevron-back" size={22} color={COLORS.textPrimary} />
            </TouchableOpacity>
          ))}
          <View style={{ height: 24 }} />
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  headerWrap: { padding: 20, paddingBottom: 4 },
  title: { fontSize: 28, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right" },
  subtitle: { fontSize: 14, color: COLORS.textSecondary, marginTop: 4, textAlign: "right", fontWeight: "600" },
  list: { padding: 20, gap: 14 },
  card: {
    flexDirection: "row-reverse",
    alignItems: "center",
    borderWidth: 2,
    borderColor: COLORS.border,
    borderRadius: 18,
    padding: 16,
    gap: 12,
  },
  emoji: { fontSize: 48 },
  cardBody: { flex: 1 },
  cardTitle: { fontSize: 20, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right" },
  cardEnglish: { fontSize: 12, fontWeight: "800", color: COLORS.textPrimary, opacity: 0.7, textAlign: "right" },
  cardDesc: { fontSize: 13, color: COLORS.textPrimary, marginTop: 4, textAlign: "right", fontWeight: "500" },
  metaRow: { flexDirection: "row-reverse", marginTop: 8 },
  metaPill: {
    flexDirection: "row-reverse",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.7)",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1.5,
    borderColor: COLORS.border,
    gap: 4,
  },
  metaText: { fontSize: 11, fontWeight: "800", color: COLORS.textPrimary },
});
