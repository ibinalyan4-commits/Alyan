import { useEffect, useState } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView, Switch,
  TextInput, Alert, Platform, ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { COLORS, NEO_SHADOW, NEO_SHADOW_SM } from "../constants/theme";
import { getUser, saveUser, clearUser } from "../utils/user";
import { BACKEND_URL } from "../constants/theme";
import {
  getSettings, saveSettings, scheduleDailyReminder,
  cancelReminder, requestPermission, ReminderSettings, DEFAULT_SETTINGS,
} from "../utils/notifications";

const HOURS = Array.from({ length: 24 }, (_, i) => i);
const MINUTES = [0, 15, 30, 45];

export default function Settings() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [settings, setSettings] = useState<ReminderSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      const u = await getUser();
      const s = await getSettings();
      if (u) setName(u.name);
      setSettings(s);
      setLoading(false);
    })();
  }, []);

  const updateSetting = async (patch: Partial<ReminderSettings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    await saveSettings(next);

    if (next.enabled) {
      const ok = await requestPermission();
      if (!ok && Platform.OS !== "web") {
        Alert.alert("صلاحيات مرفوضة", "يجب السماح بالإشعارات لاستقبال التذكيرات.");
        const reverted = { ...next, enabled: false };
        setSettings(reverted);
        await saveSettings(reverted);
        return;
      }
      try {
        await scheduleDailyReminder(next.hour, next.minute, name);
      } catch (e) { console.error(e); }
    } else {
      await cancelReminder();
    }
  };

  const saveName = async () => {
    const trimmed = name.trim();
    if (!trimmed) return;
    setSaving(true);
    const u = await saveUser(trimmed);
    // Sync to server so leaderboard reflects it
    try {
      await fetch(`${BACKEND_URL}/api/progress/name`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: u.userId, name: trimmed }),
      });
    } catch (e) { console.error(e); }
    setSaving(false);
    Alert.alert("تم الحفظ", "تم تحديث اسمك");
  };

  const resetAccount = () => {
    Alert.alert(
      "إعادة تعيين الحساب",
      "سيتم مسح اسمك والإشعارات. التقدم على الخادم سيبقى.",
      [
        { text: "إلغاء", style: "cancel" },
        {
          text: "تأكيد",
          style: "destructive",
          onPress: async () => {
            await clearUser();
            await cancelReminder();
            router.replace("/");
          },
        },
      ],
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.safe}>
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 100 }} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, NEO_SHADOW_SM]} testID="settings-back">
          <Ionicons name="chevron-forward" size={22} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.title}>الإعدادات</Text>
        <View style={{ width: 38 }} />
      </View>

      <ScrollView contentContainerStyle={styles.body} showsVerticalScrollIndicator={false}>
        {/* Profile */}
        <Text style={styles.sectionTitle}>الملف الشخصي</Text>
        <View style={[styles.card, NEO_SHADOW]}>
          <Text style={styles.label}>الاسم</Text>
          <View style={styles.row}>
            <TextInput
              testID="settings-name-input"
              style={styles.input}
              value={name}
              onChangeText={setName}
              maxLength={30}
              placeholder="اسمك"
              placeholderTextColor={COLORS.placeholder}
            />
            <TouchableOpacity
              testID="settings-save-name"
              style={[styles.smallBtn, NEO_SHADOW_SM, { backgroundColor: COLORS.primary }]}
              onPress={saveName}
              disabled={saving}
            >
              <Text style={styles.smallBtnText}>حفظ</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Reminders */}
        <Text style={styles.sectionTitle}>تذكير يومي</Text>
        <View style={[styles.card, NEO_SHADOW]}>
          <View style={styles.row}>
            <Text style={styles.label}>تفعيل التذكير</Text>
            <Switch
              testID="settings-reminder-toggle"
              value={settings.enabled}
              onValueChange={(v) => updateSetting({ enabled: v })}
              trackColor={{ false: COLORS.muted, true: COLORS.success }}
              thumbColor={COLORS.surface}
            />
          </View>

          {Platform.OS === "web" && settings.enabled && (
            <Text style={styles.warn}>
              ⚠️ الإشعارات لا تعمل على متصفح الويب — جرّب على الجوال
            </Text>
          )}

          <View style={{ marginTop: 14, opacity: settings.enabled ? 1 : 0.4, pointerEvents: settings.enabled ? "auto" : "none" }}>
            <Text style={styles.label}>الوقت (ساعة : دقيقة)</Text>

            <Text style={styles.pickerLabel}>الساعة (0 - 23)</Text>
            <View style={styles.hoursGrid}>
              {HOURS.map(h => (
                <TouchableOpacity
                  key={h}
                  testID={`settings-hour-${h}`}
                  style={[
                    styles.hourChip,
                    NEO_SHADOW_SM,
                    settings.hour === h && { backgroundColor: COLORS.primary },
                  ]}
                  onPress={() => updateSetting({ hour: h })}
                >
                  <Text style={[
                    styles.timeChipText,
                    settings.hour === h && { color: COLORS.textInverse },
                  ]}>{String(h).padStart(2, "0")}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.pickerLabel}>الدقيقة</Text>
            <View style={styles.minuteRow}>
              {MINUTES.map(m => (
                <TouchableOpacity
                  key={m}
                  testID={`settings-minute-${m}`}
                  style={[
                    styles.timeChip,
                    NEO_SHADOW_SM,
                    settings.minute === m && { backgroundColor: COLORS.primary },
                    { flex: 1 },
                  ]}
                  onPress={() => updateSetting({ minute: m })}
                >
                  <Text style={[
                    styles.timeChipText,
                    settings.minute === m && { color: COLORS.textInverse },
                  ]}>:{String(m).padStart(2, "0")}</Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.timePreview}>
              <Ionicons name="alarm" size={20} color={COLORS.primary} />
              <Text style={styles.timePreviewText}>
                {String(settings.hour).padStart(2, "0")}:{String(settings.minute).padStart(2, "0")}
              </Text>
            </View>
          </View>
        </View>

        {/* Danger */}
        <TouchableOpacity
          testID="settings-reset"
          style={[styles.dangerBtn, NEO_SHADOW]}
          onPress={resetAccount}
        >
          <Ionicons name="trash" size={18} color={COLORS.textInverse} />
          <Text style={styles.dangerText}>إعادة تعيين الحساب</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
    paddingBottom: 8,
  },
  backBtn: {
    width: 38, height: 38, borderRadius: 12,
    backgroundColor: COLORS.surface,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },
  title: { fontSize: 22, fontWeight: "900", color: COLORS.textPrimary },
  body: { padding: 16, paddingBottom: 40, gap: 12 },
  sectionTitle: {
    fontSize: 16, fontWeight: "900", color: COLORS.textSecondary,
    marginTop: 8, marginBottom: 6, textAlign: "right", letterSpacing: 0.5,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: 18, borderWidth: 2, borderColor: COLORS.border,
    padding: 16,
  },
  label: { fontSize: 14, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right" },
  row: { flexDirection: "row-reverse", alignItems: "center", gap: 10 },
  input: {
    flex: 1,
    backgroundColor: COLORS.bg,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 12, padding: 12,
    fontSize: 15, color: COLORS.textPrimary, textAlign: "right", fontWeight: "700",
  },
  smallBtn: {
    paddingHorizontal: 18, paddingVertical: 12,
    borderRadius: 12, borderWidth: 2, borderColor: COLORS.border,
  },
  smallBtnText: { color: COLORS.textInverse, fontWeight: "900", fontSize: 14 },

  pickerLabel: { fontSize: 12, fontWeight: "800", color: COLORS.textSecondary, marginTop: 12, marginBottom: 6, textAlign: "right" },
  scrollRow: { gap: 8, paddingVertical: 4 },
  hoursGrid: {
    flexDirection: "row-reverse",
    flexWrap: "wrap",
    gap: 6,
    paddingVertical: 4,
    width: "100%",
  },
  hourChip: {
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 12,
    paddingVertical: 10,
    alignItems: "center", justifyContent: "center",
    flexBasis: "15%",
    flexGrow: 0,
    minWidth: 44,
  },
  timeChip: {
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 12,
    paddingHorizontal: 14, paddingVertical: 10,
    alignItems: "center", justifyContent: "center",
    minWidth: 50,
  },
  timeChipText: { fontWeight: "900", color: COLORS.textPrimary, fontSize: 15 },
  minuteRow: { flexDirection: "row-reverse", gap: 8 },

  timePreview: {
    flexDirection: "row-reverse",
    alignItems: "center", justifyContent: "center",
    gap: 8,
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 14, padding: 14, marginTop: 16,
  },
  timePreviewText: { fontSize: 28, fontWeight: "900", color: COLORS.primary, letterSpacing: 1 },

  warn: {
    fontSize: 12, color: COLORS.warning, fontWeight: "700",
    marginTop: 8, textAlign: "right",
  },

  dangerBtn: {
    flexDirection: "row-reverse",
    alignItems: "center", justifyContent: "center",
    gap: 8,
    backgroundColor: COLORS.error,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 16, padding: 16, marginTop: 16,
  },
  dangerText: { color: COLORS.textInverse, fontWeight: "900", fontSize: 15 },
});
