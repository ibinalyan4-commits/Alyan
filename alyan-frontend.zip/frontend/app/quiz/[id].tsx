import { useEffect, useState } from "react";
import {
  View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, ScrollView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { COLORS, NEO_SHADOW, NEO_SHADOW_SM, BACKEND_URL } from "../../constants/theme";
import { playTTS } from "../../utils/audio";
import { getUser } from "../../utils/user";
import Celebration from "../../components/Celebration";

type Q = { id: string; question_en: string; options: string[]; correct_ar: string };

export default function Quiz() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const [questions, setQuestions] = useState<Q[]>([]);
  const [token, setToken] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [idx, setIdx] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [answers, setAnswers] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [done, setDone] = useState(false);
  const [celebrate, setCelebrate] = useState(false);
  const [serverScore, setServerScore] = useState<{ score: number; total: number; xp: number; correct: string[] } | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetch(`${BACKEND_URL}/api/quiz/${id}`)
      .then(r => r.json())
      .then(d => {
        setQuestions(d.questions || []);
        setToken(d.token || "");
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [id]);

  const submitLocal = () => {
    if (!selected) return;
    setSubmitted(true);
    setAnswers(prev => [...prev, selected]);
    if (selected === questions[idx].correct_ar) {
      setCelebrate(true);
    }
  };

  const nextQ = async () => {
    if (idx + 1 >= questions.length) {
      setSubmitting(true);
      try {
        const u = await getUser();
        const uid = u?.userId || "default";
        const res = await fetch(`${BACKEND_URL}/api/quiz/submit`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            user_id: uid,
            name: u?.name || "",
            token,
            answers: answers,
          }),
        });
        const data = await res.json();
        if (res.ok) {
          setServerScore({
            score: data.score,
            total: data.total,
            xp: data.xp_awarded,
            correct: data.correct_answers || [],
          });
          if (data.score > 0) setCelebrate(true);
        }
      } catch (e) { console.error(e); }
      setSubmitting(false);
      setDone(true);
    } else {
      setIdx(i => i + 1);
      setSelected(null);
      setSubmitted(false);
    }
  };

  // Show celebration on each correct submission visually (we don't know correctness until server submit)
  // For UX during the quiz, we just visually show the user's choice; correctness reveals at the end.

  if (loading) {
    return (
      <SafeAreaView style={styles.safe}>
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 100 }} />
      </SafeAreaView>
    );
  }

  if (done) {
    const score = serverScore?.score ?? 0;
    const total = serverScore?.total ?? questions.length;
    const xp = serverScore?.xp ?? 0;
    const percent = total > 0 ? Math.round((score / total) * 100) : 0;
    return (
      <SafeAreaView style={styles.safe} edges={["top"]}>
        {submitting && <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 100 }} />}
        {!submitting && (
          <View style={styles.resultWrap}>
            <Text style={styles.resultEmoji}>{percent >= 70 ? "🎉" : "💪"}</Text>
            <Text style={styles.resultTitle}>{percent >= 70 ? "أحسنت!" : "حاول مرة أخرى!"}</Text>
            <View style={[styles.scoreCard, NEO_SHADOW]}>
              <Text style={styles.scoreLabel}>نتيجتك</Text>
              <Text style={styles.scoreValue}>{score} / {total}</Text>
              <Text style={styles.scorePercent}>{percent}%</Text>
              <View style={styles.xpBadge}>
                <Ionicons name="star" size={18} color={COLORS.textPrimary} />
                <Text style={styles.xpBadgeText}>+{xp} نقطة</Text>
              </View>
            </View>
            <TouchableOpacity
              testID="quiz-done-back"
              style={[styles.doneBtn, NEO_SHADOW]}
              onPress={() => router.replace("/(tabs)")}
              activeOpacity={0.85}
            >
              <Text style={styles.doneBtnText}>العودة للرئيسية</Text>
            </TouchableOpacity>
          </View>
        )}
        <Celebration visible={celebrate} onDone={() => setCelebrate(false)} />
      </SafeAreaView>
    );
  }

  if (!questions.length) {
    return (
      <SafeAreaView style={styles.safe}>
        <Text style={{ textAlign: "center", marginTop: 100, fontSize: 16 }}>لا توجد أسئلة</Text>
      </SafeAreaView>
    );
  }

  const q = questions[idx];
  const isCorrect = submitted && selected === q.correct_ar;

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <View style={styles.headerBar}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, NEO_SHADOW_SM]} testID="quiz-back">
          <Ionicons name="close" size={22} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <View style={styles.progressOuter}>
          <View style={[styles.progressInner, { width: `${((idx) / questions.length) * 100}%` }]} />
        </View>
        <Text style={styles.qCount}>{idx + 1}/{questions.length}</Text>
      </View>

      <ScrollView contentContainerStyle={styles.body}>
        <Text style={styles.prompt}>ما معنى هذه الكلمة بالعربية؟</Text>

        <View style={[styles.questionCard, NEO_SHADOW]}>
          <Text style={styles.questionWord}>{q.question_en}</Text>
          <TouchableOpacity
            style={[styles.listenSmall, NEO_SHADOW_SM]}
            onPress={() => playTTS(q.question_en)}
            testID="quiz-listen"
          >
            <Ionicons name="volume-high" size={18} color={COLORS.textInverse} />
          </TouchableOpacity>
        </View>

        <View style={styles.options}>
          {q.options.map((opt, i) => {
            const isSelected = selected === opt;
            const showCorrect = submitted && opt === q.correct_ar;
            const showWrong = submitted && isSelected && opt !== q.correct_ar;
            return (
              <TouchableOpacity
                key={i}
                testID={`quiz-option-${i}`}
                disabled={submitted}
                activeOpacity={0.85}
                style={[
                  styles.option,
                  NEO_SHADOW_SM,
                  isSelected && !submitted && styles.optionSelected,
                  showCorrect && { backgroundColor: COLORS.success, borderColor: COLORS.textPrimary },
                  showWrong && { backgroundColor: COLORS.error, borderColor: COLORS.textPrimary },
                ]}
                onPress={() => setSelected(opt)}
              >
                <Text style={[
                  styles.optionText,
                  (isSelected && !submitted) && { color: COLORS.textInverse },
                  (showCorrect || showWrong) && { color: COLORS.textInverse },
                ]}>{opt}</Text>
                {showCorrect && <Ionicons name="checkmark-circle" size={24} color={COLORS.textInverse} />}
                {showWrong && <Ionicons name="close-circle" size={24} color={COLORS.textInverse} />}
              </TouchableOpacity>
            );
          })}
        </View>

        {submitted && (
          <View style={[styles.feedback, isCorrect ? styles.feedbackOk : styles.feedbackBad, NEO_SHADOW_SM]}>
            <Text style={styles.feedbackText}>
              {isCorrect ? "✅ ممتاز! إجابة صحيحة" : `❌ الإجابة الصحيحة: ${q.correct_ar}`}
            </Text>
          </View>
        )}
      </ScrollView>

      <View style={styles.footer}>
        {!submitted ? (
          <TouchableOpacity
            testID="quiz-submit"
            disabled={!selected}
            style={[styles.submitBtn, NEO_SHADOW, !selected && { opacity: 0.4 }]}
            onPress={submitLocal}
            activeOpacity={0.85}
          >
            <Text style={styles.submitText}>تحقق</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            testID="quiz-next"
            style={[styles.submitBtn, NEO_SHADOW, { backgroundColor: COLORS.success }, (submitting || celebrate) && { opacity: 0.5 }]}
            onPress={nextQ}
            disabled={submitting || celebrate}
            activeOpacity={0.85}
          >
            <Text style={styles.submitText}>
              {celebrate ? "🎉 رائع..." : (idx + 1 >= questions.length ? "إنهاء" : "التالي")}
            </Text>
          </TouchableOpacity>
        )}
      </View>

      <Celebration visible={celebrate} onDone={() => setCelebrate(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  headerBar: {
    flexDirection: "row-reverse",
    alignItems: "center",
    padding: 16,
    gap: 12,
  },
  backBtn: {
    width: 38, height: 38, borderRadius: 12,
    backgroundColor: COLORS.surface,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },
  progressOuter: {
    flex: 1, height: 14,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 999,
    backgroundColor: COLORS.muted,
    overflow: "hidden",
  },
  progressInner: { height: "100%", backgroundColor: COLORS.success },
  qCount: { fontWeight: "900", color: COLORS.textPrimary, fontSize: 13 },

  body: { padding: 20, paddingBottom: 40 },
  prompt: { fontSize: 14, color: COLORS.textSecondary, fontWeight: "700", textAlign: "right", marginBottom: 16 },
  questionCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 22, borderWidth: 2, borderColor: COLORS.border,
    padding: 30, alignItems: "center", marginBottom: 24,
  },
  questionWord: { fontSize: 46, fontWeight: "900", color: COLORS.textPrimary, letterSpacing: 1 },
  listenSmall: {
    backgroundColor: COLORS.primary,
    borderWidth: 2, borderColor: COLORS.border,
    width: 44, height: 44, borderRadius: 12,
    alignItems: "center", justifyContent: "center",
    marginTop: 14,
  },
  options: { gap: 12 },
  option: {
    backgroundColor: COLORS.surface,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 14,
    padding: 18,
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
  },
  optionSelected: { backgroundColor: COLORS.primary },
  optionText: { fontSize: 20, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right", letterSpacing: 0.3 },

  feedback: {
    marginTop: 20,
    padding: 14,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: COLORS.border,
  },
  feedbackOk: { backgroundColor: COLORS.success },
  feedbackBad: { backgroundColor: COLORS.error },
  feedbackInfo: { backgroundColor: COLORS.surface2 },
  feedbackText: { fontSize: 14, fontWeight: "900", color: COLORS.textInverse, textAlign: "right" },

  footer: {
    padding: 16,
    borderTopWidth: 2,
    borderTopColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  submitBtn: {
    backgroundColor: COLORS.primary,
    borderRadius: 16,
    borderWidth: 2, borderColor: COLORS.border,
    padding: 16,
    alignItems: "center",
  },
  submitText: { color: COLORS.textInverse, fontWeight: "900", fontSize: 17 },

  resultWrap: { flex: 1, alignItems: "center", justifyContent: "center", padding: 24, gap: 16 },
  resultEmoji: { fontSize: 80 },
  resultTitle: { fontSize: 28, fontWeight: "900", color: COLORS.textPrimary },
  scoreCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 22,
    borderWidth: 2, borderColor: COLORS.border,
    padding: 28,
    alignItems: "center",
    minWidth: 280,
  },
  scoreLabel: { fontSize: 13, fontWeight: "800", color: COLORS.textSecondary },
  scoreValue: { fontSize: 50, fontWeight: "900", color: COLORS.primary, marginTop: 4 },
  scorePercent: { fontSize: 20, fontWeight: "900", color: COLORS.textPrimary, marginTop: 4 },
  xpBadge: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
    backgroundColor: COLORS.warning,
    borderWidth: 2, borderColor: COLORS.border,
    paddingHorizontal: 16, paddingVertical: 8,
    borderRadius: 12, marginTop: 14,
  },
  xpBadgeText: { fontWeight: "900", color: COLORS.textPrimary, fontSize: 15 },
  doneBtn: {
    backgroundColor: COLORS.primary,
    borderRadius: 16,
    borderWidth: 2, borderColor: COLORS.border,
    paddingHorizontal: 28, paddingVertical: 14,
  },
  doneBtnText: { color: COLORS.textInverse, fontWeight: "900", fontSize: 16 },
});
