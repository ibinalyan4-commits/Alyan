import { useEffect, useState, useCallback } from "react";
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useRouter, useFocusEffect } from "expo-router";
import { COLORS, NEO_SHADOW, NEO_SHADOW_SM, BACKEND_URL } from "../constants/theme";
import { getUser } from "../utils/user";

type Entry = {
  rank: number;
  user_id: string;
  name: string;
  xp: number;
  level: number;
  streak: number;
};

const RANK_STYLE: Record<number, { bg: string; emoji: string }> = {
  1: { bg: "#D4AF37", emoji: "🥇" },
  2: { bg: "#C0C0C0", emoji: "🥈" },
  3: { bg: "#CD7F32", emoji: "🥉" },
};

export default function Leaderboard() {
  const router = useRouter();
  const [entries, setEntries] = useState<Entry[]>([]);
  const [loading, setLoading] = useState(true);
  const [myUserId, setMyUserId] = useState<string>("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const u = await getUser();
      if (u) setMyUserId(u.userId);
      const data = await fetch(`${BACKEND_URL}/api/leaderboard?limit=10`).then(r => r.json());
      setEntries(data.leaderboard || []);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, NEO_SHADOW_SM]} testID="leaderboard-back">
          <Ionicons name="chevron-forward" size={22} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.title}>🏆 المتصدرون</Text>
        <TouchableOpacity onPress={load} style={[styles.backBtn, NEO_SHADOW_SM]} testID="leaderboard-refresh">
          <Ionicons name="refresh" size={20} color={COLORS.textPrimary} />
        </TouchableOpacity>
      </View>
      <Text style={styles.subtitle}>أفضل 10 مستخدمين بالنقاط</Text>

      {loading ? (
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 80 }} />
      ) : entries.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyEmoji}>🏆</Text>
          <Text style={styles.emptyText}>لا يوجد متسابقون بعد</Text>
          <Text style={styles.emptyHint}>كن أول من يحصل على نقاط!</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.list} showsVerticalScrollIndicator={false}>
          {/* Top 3 podium */}
          <View style={styles.podium}>
            {entries.slice(0, 3).map((e) => {
              const style = RANK_STYLE[e.rank];
              const isMe = e.user_id === myUserId;
              return (
                <View
                  key={e.user_id}
                  testID={`podium-${e.rank}`}
                  style={[
                    styles.podiumCard,
                    NEO_SHADOW,
                    { backgroundColor: style?.bg || COLORS.surface2 },
                    e.rank === 1 && { transform: [{ scale: 1.05 }] },
                  ]}
                >
                  <Text style={styles.podiumEmoji}>{style?.emoji}</Text>
                  <Text style={styles.podiumName} numberOfLines={1}>
                    {e.name} {isMe ? "(أنت)" : ""}
                  </Text>
                  <Text style={styles.podiumXp}>{e.xp} نقطة</Text>
                  <Text style={styles.podiumLevel}>المستوى {e.level}</Text>
                </View>
              );
            })}
          </View>

          {/* Ranks 4-10 */}
          {entries.slice(3).map(e => {
            const isMe = e.user_id === myUserId;
            return (
              <View
                key={e.user_id}
                testID={`rank-${e.rank}`}
                style={[
                  styles.rankRow,
                  NEO_SHADOW_SM,
                  isMe && { backgroundColor: COLORS.surface2, borderColor: COLORS.primary },
                ]}
              >
                <View style={styles.rankBadge}>
                  <Text style={styles.rankNum}>#{e.rank}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.rankName} numberOfLines={1}>
                    {e.name} {isMe ? "(أنت)" : ""}
                  </Text>
                  <View style={styles.rankMeta}>
                    <Text style={styles.rankMetaText}>المستوى {e.level}</Text>
                    <Text style={styles.rankMetaSep}>•</Text>
                    <Ionicons name="flame" size={12} color={COLORS.warning} />
                    <Text style={styles.rankMetaText}>{e.streak} يوم</Text>
                  </View>
                </View>
                <View style={styles.xpBadge}>
                  <Text style={styles.xpText}>{e.xp}</Text>
                  <Text style={styles.xpLabel}>نقطة</Text>
                </View>
              </View>
            );
          })}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  header: {
    flexDirection: "row-reverse",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16, paddingBottom: 4,
  },
  backBtn: {
    width: 38, height: 38, borderRadius: 12,
    backgroundColor: COLORS.surface,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },
  title: { fontSize: 22, fontWeight: "900", color: COLORS.textPrimary, letterSpacing: 0.5 },
  subtitle: { fontSize: 13, color: COLORS.textSecondary, fontWeight: "700", textAlign: "center", marginBottom: 12 },

  list: { padding: 16, paddingBottom: 40, gap: 10 },

  podium: {
    flexDirection: "row-reverse",
    justifyContent: "center",
    alignItems: "flex-end",
    gap: 8, marginBottom: 16,
  },
  podiumCard: {
    flex: 1,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 18,
    padding: 12,
    alignItems: "center",
    minHeight: 130,
  },
  podiumEmoji: { fontSize: 36 },
  podiumName: { fontSize: 14, fontWeight: "900", color: COLORS.textInverse, marginTop: 4, textAlign: "center" },
  podiumXp: { fontSize: 16, fontWeight: "900", color: COLORS.textInverse, marginTop: 4 },
  podiumLevel: { fontSize: 11, fontWeight: "800", color: COLORS.textInverse, opacity: 0.85 },

  rankRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    backgroundColor: COLORS.surface,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 16, padding: 12, gap: 12,
  },
  rankBadge: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: COLORS.surface2,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },
  rankNum: { fontSize: 14, fontWeight: "900", color: COLORS.textPrimary },
  rankName: { fontSize: 16, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right" },
  rankMeta: { flexDirection: "row-reverse", alignItems: "center", gap: 4, marginTop: 2 },
  rankMetaText: { fontSize: 11, color: COLORS.textSecondary, fontWeight: "700" },
  rankMetaSep: { color: COLORS.textSecondary, fontWeight: "900" },
  xpBadge: {
    backgroundColor: COLORS.primary,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 12, paddingHorizontal: 12, paddingVertical: 6,
    alignItems: "center",
  },
  xpText: { fontSize: 18, fontWeight: "900", color: COLORS.textInverse },
  xpLabel: { fontSize: 9, fontWeight: "800", color: COLORS.textInverse, opacity: 0.8 },

  empty: { alignItems: "center", justifyContent: "center", padding: 40, gap: 8, marginTop: 40 },
  emptyEmoji: { fontSize: 70 },
  emptyText: { fontSize: 18, fontWeight: "900", color: COLORS.textPrimary },
  emptyHint: { fontSize: 13, color: COLORS.textSecondary, fontWeight: "700" },
});
