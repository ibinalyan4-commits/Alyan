import { useEffect, useState } from "react";
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { COLORS, NEO_SHADOW, NEO_SHADOW_SM, BACKEND_URL } from "../../constants/theme";
import { playTTS } from "../../utils/audio";
import { getUser } from "../../utils/user";
import Celebration from "../../components/Celebration";

type Word = { en: string; ar: string; example_en: string; example_ar: string };
type Cat = { id: string; name_ar: string; name_en: string; emoji: string; color: string };

export default function LessonDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const [words, setWords] = useState<Word[]>([]);
  const [cat, setCat] = useState<Cat | null>(null);
  const [loading, setLoading] = useState(true);
  const [completed, setCompleted] = useState(false);
  const [celebrate, setCelebrate] = useState(false);

  useEffect(() => {
    fetch(`${BACKEND_URL}/api/lessons/${id}`)
      .then(r => r.json())
      .then(d => {
        setWords(d.words);
        setCat(d.category);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [id]);

  const completeLesson = async () => {
    if (completed) return;
    setCompleted(true);
    setCelebrate(true);
    try {
      const u = await getUser();
      const uid = u?.userId || "default";
      await fetch(`${BACKEND_URL}/api/lesson/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: uid,
          name: u?.name || "",
          lesson_id: id,
        }),
      });
    } catch (e) { console.error(e); }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.safe}>
        <ActivityIndicator size="large" color={COLORS.primary} style={{ marginTop: 100 }} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <View style={[styles.header, { backgroundColor: cat?.color || COLORS.primary }]}>
        <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, NEO_SHADOW_SM]} testID="lesson-back">
          <Ionicons name="chevron-forward" size={24} color={COLORS.textPrimary} />
        </TouchableOpacity>
        <View style={{ flex: 1, alignItems: "flex-end" }}>
          <Text style={styles.headerEmoji}>{cat?.emoji}</Text>
          <Text style={styles.headerTitle}>{cat?.name_ar}</Text>
          <Text style={styles.headerSub}>{cat?.name_en} • {words.length} كلمة</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.list} showsVerticalScrollIndicator={false}>
        {words.map((w, i) => (
          <View key={i} style={[styles.wordCard, NEO_SHADOW_SM]} testID={`word-${i}`}>
            <View style={styles.wordHeader}>
              <Text style={styles.wordAr}>{w.ar}</Text>
              <View style={styles.numBadge}>
                <Text style={styles.numText}>{i + 1}</Text>
              </View>
            </View>
            <Text style={styles.wordEn}>{w.en}</Text>
            <View style={styles.divider} />
            <Text style={styles.exampleAr}>{w.example_ar}</Text>
            <Text style={styles.exampleEn}>{w.example_en}</Text>
            <TouchableOpacity
              testID={`tts-${i}`}
              style={[styles.listenBtn, NEO_SHADOW_SM]}
              onPress={() => playTTS(w.example_en)}
              activeOpacity={0.85}
            >
              <Ionicons name="volume-high" size={18} color={COLORS.textInverse} />
              <Text style={styles.listenText}>استمع للنطق</Text>
            </TouchableOpacity>
          </View>
        ))}

        <TouchableOpacity
          testID="complete-lesson"
          style={[styles.completeBtn, NEO_SHADOW, completed && { backgroundColor: COLORS.success }]}
          onPress={completed ? () => router.push(`/quiz/${id}`) : completeLesson}
          activeOpacity={0.85}
        >
          <Ionicons
            name={completed ? "checkmark-circle" : "trophy"}
            size={24}
            color={COLORS.textPrimary}
          />
          <Text style={styles.completeText}>
            {completed ? "ابدأ الاختبار +20 XP" : "أكملت الدرس - احصل على 20 XP"}
          </Text>
        </TouchableOpacity>
      </ScrollView>

      <Celebration visible={celebrate} message="درس مكتمل!" onDone={() => setCelebrate(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  header: {
    flexDirection: "row-reverse",
    padding: 20,
    paddingBottom: 28,
    borderBottomWidth: 2,
    borderBottomColor: COLORS.border,
    alignItems: "flex-start",
  },
  backBtn: {
    width: 42, height: 42,
    backgroundColor: COLORS.surface,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 12,
    alignItems: "center", justifyContent: "center",
  },
  headerEmoji: { fontSize: 38 },
  headerTitle: { fontSize: 26, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right" },
  headerSub: { fontSize: 13, color: COLORS.textPrimary, fontWeight: "700", opacity: 0.8, textAlign: "right" },
  list: { padding: 16, gap: 12, paddingBottom: 32 },
  wordCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 18,
    borderWidth: 2,
    borderColor: COLORS.border,
    padding: 16,
  },
  wordHeader: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" },
  wordAr: { fontSize: 26, fontWeight: "900", color: COLORS.textPrimary, textAlign: "right", flex: 1, letterSpacing: 0.3 },
  numBadge: {
    width: 32, height: 32, borderRadius: 10,
    backgroundColor: COLORS.warning,
    borderWidth: 2, borderColor: COLORS.border,
    alignItems: "center", justifyContent: "center",
  },
  numText: { fontSize: 13, fontWeight: "900", color: COLORS.textPrimary },
  wordEn: { fontSize: 32, fontWeight: "900", color: COLORS.primary, marginTop: 4, letterSpacing: 0.5 },
  divider: { height: 1.5, backgroundColor: COLORS.borderSubtle, marginVertical: 12 },
  exampleAr: { fontSize: 14, color: COLORS.textPrimary, fontWeight: "600", textAlign: "right" },
  exampleEn: { fontSize: 16, color: COLORS.textSecondary, marginTop: 4, fontStyle: "italic" },
  listenBtn: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 8,
    backgroundColor: COLORS.primary,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 12,
    paddingHorizontal: 14, paddingVertical: 10,
    marginTop: 12,
    alignSelf: "flex-start",
  },
  listenText: { color: COLORS.textInverse, fontWeight: "900", fontSize: 13 },
  completeBtn: {
    flexDirection: "row-reverse",
    alignItems: "center", justifyContent: "center",
    gap: 10,
    backgroundColor: COLORS.warning,
    borderWidth: 2, borderColor: COLORS.border,
    borderRadius: 16,
    padding: 18,
    marginTop: 8,
  },
  completeText: { fontWeight: "900", fontSize: 15, color: COLORS.textPrimary },
});
