import { useEffect, useRef } from "react";
import { Animated, StyleSheet, Text, View, Dimensions } from "react-native";
import { COLORS } from "../constants/theme";

const { width } = Dimensions.get("window");

type Props = {
  visible: boolean;
  message?: string;
  onDone?: () => void;
};

const EMOJIS = ["🎉", "✨", "🌟", "🎊", "👏", "💫"];

export default function Celebration({ visible, message = "أحسنت!", onDone }: Props) {
  const scale = useRef(new Animated.Value(0)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const confetti = useRef(EMOJIS.map(() => new Animated.Value(0))).current;

  useEffect(() => {
    if (!visible) return;
    scale.setValue(0);
    opacity.setValue(0);
    confetti.forEach(v => v.setValue(0));

    Animated.parallel([
      Animated.spring(scale, { toValue: 1, useNativeDriver: true, friction: 5, tension: 80 }),
      Animated.timing(opacity, { toValue: 1, duration: 200, useNativeDriver: true }),
      ...confetti.map((v, i) =>
        Animated.timing(v, { toValue: 1, duration: 900 + i * 80, useNativeDriver: true, delay: i * 50 })
      ),
    ]).start();

    const t = setTimeout(() => {
      Animated.timing(opacity, { toValue: 0, duration: 250, useNativeDriver: true }).start(() => {
        onDone?.();
      });
    }, 1400);
    return () => clearTimeout(t);
  }, [visible]);

  if (!visible) return null;

  return (
    <View style={[styles.wrap, { pointerEvents: "none" }]}>
      {confetti.map((v, i) => {
        const tx = v.interpolate({
          inputRange: [0, 1],
          outputRange: [0, (i % 2 === 0 ? -1 : 1) * (width / 2 - 30 - i * 8)],
        });
        const ty = v.interpolate({
          inputRange: [0, 1],
          outputRange: [0, -180 - (i * 18)],
        });
        const rot = v.interpolate({ inputRange: [0, 1], outputRange: ["0deg", `${(i % 2 ? 360 : -360)}deg`] });
        const op = v.interpolate({ inputRange: [0, 0.5, 1], outputRange: [1, 1, 0] });
        return (
          <Animated.Text
            key={i}
            style={[
              styles.confetti,
              { transform: [{ translateX: tx }, { translateY: ty }, { rotate: rot }], opacity: op },
            ]}
          >
            {EMOJIS[i]}
          </Animated.Text>
        );
      })}
      <Animated.View style={[styles.badge, { opacity, transform: [{ scale }] }]}>
        <Text style={styles.emoji}>🎉</Text>
        <Text style={styles.text}>{message}</Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
    zIndex: 999,
  },
  confetti: {
    position: "absolute",
    fontSize: 36,
  },
  badge: {
    backgroundColor: COLORS.success,
    borderWidth: 3,
    borderColor: COLORS.textPrimary,
    borderRadius: 24,
    paddingVertical: 18,
    paddingHorizontal: 36,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 6, height: 6 },
    shadowOpacity: 0.7,
    shadowRadius: 0,
    elevation: 12,
  },
  emoji: { fontSize: 56 },
  text: { fontSize: 26, fontWeight: "900", color: COLORS.textInverse, marginTop: 4, letterSpacing: 0.5 },
});
