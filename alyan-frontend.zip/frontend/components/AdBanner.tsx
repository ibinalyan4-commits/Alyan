// Realistic Google AdMob banner mock for preview/Expo Go.
// On a native dev/production build with `react-native-google-mobile-ads` installed
// AND `EXPO_PUBLIC_ADMOB_BANNER_ID` provided, this swaps automatically to the real ad.

import React, { useMemo } from "react";
import { View, Text, StyleSheet, Platform, TouchableOpacity, Image } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../constants/theme";

const AD_UNIT_ID = process.env.EXPO_PUBLIC_ADMOB_BANNER_ID;

type Props = {
  variant?: "banner" | "large";   // banner = 50dp height, large = 100dp
  testID?: string;
};

// Sample creatives that rotate so user sees variety
const SAMPLE_ADS: Array<{
  emoji: string;
  title: string;
  desc: string;
  cta: string;
  bg: string;
  iconBg: string;
}> = [
  { emoji: "🎮", title: "Mobile Legends", desc: "5v5 MOBA — العب مجاناً الآن", cta: "تثبيت", bg: "#1A2332", iconBg: "#3B82F6" },
  { emoji: "🛒", title: "Amazon Shopping", desc: "خصومات حتى 70% — توصيل مجاني", cta: "افتح", bg: "#1A1A1A", iconBg: "#FF9500" },
  { emoji: "🏃", title: "Nike Training Club", desc: "تمارين رياضية مجانية", cta: "تثبيت", bg: "#0A0A0A", iconBg: "#000000" },
  { emoji: "🍔", title: "هنقرستيشن", desc: "اطلب ووصل في 30 دقيقة", cta: "اطلب الآن", bg: "#2A1A0F", iconBg: "#FF5722" },
  { emoji: "🚗", title: "كريم", desc: "احجز رحلتك بضغطة زر", cta: "احجز", bg: "#0F1F1A", iconBg: "#0FAF4F" },
];

function pickAd(seed: number) {
  return SAMPLE_ADS[seed % SAMPLE_ADS.length];
}

export default function AdBanner({ variant = "banner", testID }: Props) {
  // Try to load the native AdMob banner only on real native runtime
  if (AD_UNIT_ID && Platform.OS !== "web") {
    try {
      const mobileAds = require("react-native-google-mobile-ads");
      const BannerAd = mobileAds.BannerAd;
      const BannerAdSize = mobileAds.BannerAdSize;
      return (
        <View style={[styles.wrap, variant === "large" && styles.wrapLarge]} testID={testID || "ad-banner"}>
          <BannerAd
            unitId={AD_UNIT_ID}
            size={variant === "large" ? BannerAdSize.LARGE_BANNER : BannerAdSize.BANNER}
            requestOptions={{ requestNonPersonalizedAdsOnly: true }}
          />
        </View>
      );
    } catch {
      // Module not installed yet — fall through to mock
    }
  }

  // Pick a (semi-)random sample creative on each render based on minute timestamp
  const ad = useMemo(() => pickAd(Math.floor(Date.now() / 60000)), []);

  if (variant === "large") {
    return (
      <View style={[styles.wrap, styles.wrapLarge]} testID={testID || "ad-banner"}>
        <View style={[styles.adCard, styles.adCardLarge, { backgroundColor: ad.bg }]}>
          <View style={styles.adBadgeRow}>
            <View style={styles.adLabelBox}>
              <Text style={styles.adLabelText}>Ad</Text>
            </View>
            <Text style={styles.adSponsoredText}>· إعلان ممول</Text>
            <View style={{ flex: 1 }} />
            <Ionicons name="information-circle-outline" size={14} color="#9A9AA0" />
          </View>
          <View style={styles.adContentRow}>
            <View style={[styles.appIcon, styles.appIconLarge, { backgroundColor: ad.iconBg }]}>
              <Text style={styles.appIconEmoji}>{ad.emoji}</Text>
            </View>
            <View style={{ flex: 1, marginHorizontal: 10 }}>
              <Text style={styles.adTitleLarge} numberOfLines={1}>{ad.title}</Text>
              <Text style={styles.adDescLarge} numberOfLines={2}>{ad.desc}</Text>
              <View style={styles.starsRow}>
                {[1, 2, 3, 4, 5].map((i) => (
                  <Ionicons key={i} name={i <= 4 ? "star" : "star-half"} size={11} color="#FFC857" />
                ))}
                <Text style={styles.ratingText}>4.5  · مجاني</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.installBtn} activeOpacity={0.85}>
              <Text style={styles.installBtnText}>{ad.cta}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }

  // Standard banner (320×50-ish)
  return (
    <View style={styles.wrap} testID={testID || "ad-banner"}>
      <View style={[styles.adCard, { backgroundColor: ad.bg }]}>
        <View style={styles.adContentRow}>
          <View style={styles.adLabelBox}>
            <Text style={styles.adLabelText}>Ad</Text>
          </View>
          <View style={[styles.appIcon, { backgroundColor: ad.iconBg }]}>
            <Text style={styles.appIconEmojiSm}>{ad.emoji}</Text>
          </View>
          <View style={{ flex: 1, marginHorizontal: 8 }}>
            <Text style={styles.adTitle} numberOfLines={1}>{ad.title}</Text>
            <Text style={styles.adDesc} numberOfLines={1}>{ad.desc}</Text>
          </View>
          <TouchableOpacity style={styles.installBtnSm} activeOpacity={0.85}>
            <Text style={styles.installBtnTextSm}>{ad.cta}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    width: "100%",
    paddingHorizontal: 8,
    paddingVertical: 6,
    backgroundColor: COLORS.bg,
  },
  wrapLarge: {
    paddingVertical: 8,
  },
  adCard: {
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
    paddingHorizontal: 8,
    paddingVertical: 6,
    minHeight: 56,
    justifyContent: "center",
  },
  adCardLarge: {
    minHeight: 96,
    paddingVertical: 8,
  },
  adBadgeRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
    marginBottom: 6,
  },
  adContentRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 6,
  },
  adLabelBox: {
    backgroundColor: "#FFC857",
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: 3,
  },
  adLabelText: {
    fontSize: 10,
    fontWeight: "900",
    color: "#1A1A1A",
    letterSpacing: 0.5,
  },
  adSponsoredText: {
    fontSize: 10,
    color: "#9A9AA0",
    fontWeight: "600",
  },
  appIcon: {
    width: 36,
    height: 36,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  appIconLarge: {
    width: 56,
    height: 56,
    borderRadius: 12,
  },
  appIconEmoji: { fontSize: 28 },
  appIconEmojiSm: { fontSize: 20 },
  adTitle: {
    fontSize: 13,
    fontWeight: "800",
    color: "#FFFFFF",
    textAlign: "right",
  },
  adTitleLarge: {
    fontSize: 15,
    fontWeight: "900",
    color: "#FFFFFF",
    textAlign: "right",
  },
  adDesc: {
    fontSize: 11,
    color: "#C8C8CC",
    fontWeight: "500",
    textAlign: "right",
  },
  adDescLarge: {
    fontSize: 12,
    color: "#C8C8CC",
    fontWeight: "500",
    textAlign: "right",
    marginTop: 2,
  },
  starsRow: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 1,
    marginTop: 3,
  },
  ratingText: {
    fontSize: 10,
    color: "#9A9AA0",
    marginRight: 4,
    fontWeight: "600",
  },
  installBtn: {
    backgroundColor: "#1A73E8",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 6,
    minWidth: 70,
    alignItems: "center",
  },
  installBtnText: {
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: "900",
  },
  installBtnSm: {
    backgroundColor: "#1A73E8",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 5,
  },
  installBtnTextSm: {
    color: "#FFFFFF",
    fontSize: 11,
    fontWeight: "800",
  },
});
