// Dark grey night-mode theme
export const COLORS = {
  bg: "#1A1A1D",            // dark grey base
  surface: "#26262A",        // lighter grey for cards
  surface2: "#33333A",       // mid grey for elevated elements
  muted: "#3A3A40",
  textPrimary: "#FFFFFF",    // pure bright white
  textSecondary: "#C4C4CA",  // light grey for secondary
  textInverse: "#1A1A1D",
  placeholder: "#7A7A82",
  primary: "#E8E8EE",        // bright silver accent
  primaryHover: "#D0D0D6",
  success: "#A8C4B8",        // brighter sage
  error: "#D06868",          // brighter red
  warning: "#E0BC80",        // brighter gold
  sky: "#9AAEB8",
  pink: "#BA94A8",
  border: "#48484F",         // brighter border for visibility
  borderSubtle: "#3A3A40",
};

export const NEO_SHADOW = {
  shadowColor: "#000000",
  shadowOffset: { width: 4, height: 4 },
  shadowOpacity: 0.6,
  shadowRadius: 0,
  elevation: 6,
};

export const NEO_SHADOW_SM = {
  shadowColor: "#000000",
  shadowOffset: { width: 2, height: 2 },
  shadowOpacity: 0.6,
  shadowRadius: 0,
  elevation: 3,
};

export const BACKEND_URL = process.env.EXPO_PUBLIC_BACKEND_URL || "";
